# Qlik MCP Server

A Model Context Protocol (MCP) server that connects AI assistants like Claude to your Qlik Cloud and Qlik Sense Enterprise environments. This enables natural language interactions with your analytics platform.

**Own your AI. Create your own way to interact with your data.**

## Features

- **34 MCP Tools** across 12 categories
- **Dual Platform Support** - Qlik Cloud and Qlik Sense Enterprise (On-Premise)
- **Natural Language Analytics** - Ask questions about your data in plain English
- **Full Lifecycle Management** - Apps, reloads, users, spaces, and more
- **AI/ML Integration** - AutoML experiments, Qlik Answers assistants
- **Enterprise Governance** - Users, roles, permissions, compliance

---

## Quick Start

### Prerequisites

- **Node.js 18+** - Download from [nodejs.org](https://nodejs.org/)
- **Claude Desktop** - Download from [claude.ai/download](https://claude.ai/download)
- **Qlik Cloud tenant** OR **Qlik Sense Enterprise server**

---

### Step 1: Download the MCP Server

#### Windows (Recommended)

1. **Download the ZIP file** from GitHub:
   - Go to: https://github.com/undsoul/qlik-claude-mcp
   - Click green **"Code"** button → **"Download ZIP"**

2. **Extract to C:\** (recommended for simple paths):
   - Right-click the downloaded ZIP → **Extract All**
   - Extract to: `C:\`
   - You should now have: `C:\qlik-claude-mcp-main\`

3. **Open PowerShell** and install dependencies:
   ```powershell
   cd C:\qlik-claude-mcp-main
   npm install
   ```

#### macOS / Linux

```bash
git clone https://github.com/undsoul/qlik-claude-mcp.git
cd qlik-claude-mcp
npm install
```

---

### Step 2: Install Claude Desktop

1. Download Claude Desktop from [claude.ai/download](https://claude.ai/download)
2. Install and sign in with your Anthropic account

---

### Step 3: Get Your Qlik API Key

#### For Qlik Cloud:
1. Log in to your Qlik Cloud tenant
2. Click your **profile icon** (top right) → **Profile settings**
3. Go to **API keys** section
4. Click **Generate new key**
5. Copy and save the API key (you won't see it again!)

#### For Qlik Sense Enterprise (On-Premise):

1. Open **QMC** → **Start** → **Certificates**
2. Add a machine name (e.g., `MCP-Client`)
3. Click **Export certificates**
4. **Important settings:**
   - **Certificate file format:** Choose **PEM format** (not Windows format)
   - Check **Include secret key**
5. Export and save the files:
   - `client.pem` - Client certificate
   - `client_key.pem` - Private key
6. Note the paths where you saved these files

---

### Step 4: Configure Claude Desktop

#### Open Config File (Easiest Way)

1. **Open Claude Desktop**
2. Click **Settings** (gear icon) or **File menu**
3. Click **"Edit Config"** or **"Settings" → "Developer" → "Edit Config"**
4. This opens `claude_desktop_config.json` in your default text editor
5. Paste the configuration below and **Save** (Ctrl+S)

> **Config file location:**
> - Windows: `C:\Users\{YourName}\AppData\Roaming\Claude\claude_desktop_config.json`
> - macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`

---

#### Qlik Cloud Examples

**Windows:**
```json
{
  "mcpServers": {
    "qlik-mcp-os": {
      "command": "node",
      "args": ["C:/qlik-claude-mcp-main/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://your-tenant.eu.qlikcloud.com",
        "QLIK_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

**macOS:**
```json
{
  "mcpServers": {
    "qlik-mcp-os": {
      "command": "node",
      "args": ["/Users/yourname/qlik-claude-mcp/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://your-tenant.us.qlikcloud.com",
        "QLIK_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

---

#### Qlik Sense Enterprise (On-Premise) Examples

**Step 1: Export Certificates from QMC**

1. Open Qlik Management Console (QMC)
2. Go to **Certificates** under Configure System
3. Click **Export certificates**
4. Enter machine name (e.g., your server hostname)
5. Check **Include secret key**
6. Export format: **Platform independent PEM-format**
7. Click **Export** - saves to: `C:\ProgramData\Qlik\Sense\Repository\Exported Certificates\<machinename>\`

The folder will contain:
- `client.pem` - Client certificate
- `client_key.pem` - Client private key
- `root.pem` - Root CA certificate

**Step 2: Configure Claude Desktop**

**Windows:**
```json
{
  "mcpServers": {
    "qlik-onprem": {
      "command": "node",
      "args": ["C:/qlik-claude-mcp-main/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://qlik-server.company.com",
        "QLIK_DEPLOYMENT": "on-premise",
        "QLIK_CERT_PATH": "C:/ProgramData/Qlik/Sense/Repository/Exported Certificates/YourServer",
        "QLIK_USER_DIRECTORY": "COMPANY",
        "QLIK_USER_ID": "administrator"
      }
    }
  }
}
```

**macOS/Linux:**
```json
{
  "mcpServers": {
    "qlik-onprem": {
      "command": "node",
      "args": ["/Users/yourname/qlik-claude-mcp/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://qlik-server.company.com",
        "QLIK_DEPLOYMENT": "on-premise",
        "QLIK_CERT_PATH": "/path/to/exported-certificates",
        "QLIK_USER_DIRECTORY": "DOMAIN",
        "QLIK_USER_ID": "administrator"
      }
    }
  }
}
```

> **Note:**
> - `QLIK_CERT_PATH` is the **folder** containing `client.pem`, `client_key.pem`, and `root.pem`
> - `QLIK_USER_DIRECTORY` and `QLIK_USER_ID` specify which user to act as (e.g., `DOMAIN\administrator`)
> - The user must have appropriate access rights in QMC

---

#### Multi-Tenant & Hybrid Configurations

You can configure **multiple MCP servers** in the same config file to connect to different Qlik environments simultaneously. This supports:

- **Multiple Qlik Cloud tenants** (e.g., Dev, Test, Prod)
- **Multiple On-Premise servers**
- **Hybrid setups** (Cloud + On-Premise together)

**Example: Two Cloud Tenants + One On-Premise:**
```json
{
  "mcpServers": {
    "qlik-cloud-dev": {
      "command": "node",
      "args": ["C:/qlik-claude-mcp-main/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://dev-tenant.eu.qlikcloud.com",
        "QLIK_API_KEY": "dev-api-key-here"
      }
    },
    "qlik-cloud-prod": {
      "command": "node",
      "args": ["C:/qlik-claude-mcp-main/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://prod-tenant.eu.qlikcloud.com",
        "QLIK_API_KEY": "prod-api-key-here"
      }
    },
    "qlik-onprem": {
      "command": "node",
      "args": ["C:/qlik-claude-mcp-main/dist/index.js"],
      "env": {
        "QLIK_TENANT_URL": "https://qlik-server.company.com",
        "QLIK_DEPLOYMENT": "on-premise",
        "QLIK_CERT_PATH": "C:/ProgramData/Qlik/Sense/Repository/Exported Certificates/MyServer",
        "QLIK_USER_DIRECTORY": "COMPANY",
        "QLIK_USER_ID": "administrator"
      }
    }
  }
}
```

Each server appears as a separate MCP connection in Claude Desktop. You can specify which environment to use when asking questions:
- *"Using qlik-cloud-dev, list all apps"*
- *"On qlik-onprem, trigger reload for Sales Dashboard"*

---

### Step 5: Build the MCP Server

**After saving your config**, go back to PowerShell (Windows) or Terminal (macOS) and run:

#### Windows
```powershell
npm run build
```

#### macOS / Linux
```bash
npm run build
```

**Verify build succeeded** - you should see `dist/index.js` created.

---

### Step 6: Restart Claude Desktop

1. **Quit Claude Desktop completely** (not just close the window)
   - macOS: Right-click Claude in menu bar → Quit
   - Windows: Right-click Claude in system tray → Exit
2. **Reopen Claude Desktop**
3. Start a new conversation and try: *"Check my Qlik health"*

---

### Verify It's Working

In Claude Desktop, type:

```
Check my Qlik environment health
```

You should see Claude use the `qlik_health_check` tool and return your tenant status.

---

## Tool Capabilities (33 Tools)

### 1. Search Tools (1)

Unified search across all resources.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_search` | Search apps, datasets, automations, and more | Cloud, On-Prem |

**Example prompts:**
- "Search for apps containing 'Sales'"
- "Find all datasets in the Finance space"
- "List apps modified in the last week"

---

### 2. Governance Tools (5)

Manage users, tenants, and licenses.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_health_check` | Check server status and connectivity | Cloud, On-Prem |
| `qlik_get_tenant_info` | Get tenant/server information | Cloud, On-Prem |
| `qlik_search_users` | Search users by name or email | Cloud, On-Prem |
| `qlik_get_user_info` | Get detailed user information | Cloud, On-Prem |
| `qlik_get_license_info` | Get license and seat allocation | Cloud, On-Prem |

**Example prompts:**
- "Check the health of my Qlik environment"
- "Search for users with 'admin' in their name"
- "Show me the license information"

---

### 3. Reload Tools (3)

Manage app reloads.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_trigger_app_reload` | Trigger an app reload | Cloud, On-Prem |
| `qlik_get_reload_status` | Check reload task status | Cloud, On-Prem |
| `qlik_cancel_reload` | Cancel a running reload | Cloud, On-Prem |

**Example prompts:**
- "Reload the Sales Dashboard app"
- "What's the status of reload task abc123?"
- "Cancel the current reload"

---

### 4. Catalog Tools (1)

Browse spaces and streams.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_get_spaces_catalog` | List all spaces with details | Cloud (Spaces), On-Prem (Streams) |

**Example prompts:**
- "List all spaces in my tenant"
- "Show me the catalog of available spaces"

---

### 5. Lineage Tools (1) - Cloud Only

Track data lineage.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_get_lineage` | Get data lineage for a resource | Cloud |

**Example prompts:**
- "Show me the data lineage for dataset xyz"

---

### 6. Data Tools (5)

Interact with data and selections.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_get_dataset_details` | Get dataset/data connection details | Cloud, On-Prem |
| `qlik_apply_selections` | Apply field selections | Cloud, On-Prem |
| `qlik_clear_selections` | Clear all selections | Cloud, On-Prem |
| `qlik_get_current_selections` | Get active selections | Cloud, On-Prem |
| `qlik_get_available_fields` | List all fields in an app | Cloud, On-Prem |

**Example prompts:**
- "What fields are available in app xyz?"
- "Select 'USA' in the Country field"
- "Clear all selections in the app"

---

### 7. Misc Tools (2)

Natural language and reload info.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_insight_advisor` | Ask natural language questions | Cloud, On-Prem |
| `qlik_get_reload_info` | Get reload history for an app | Cloud, On-Prem |

**Example prompts:**
- "Ask Sales app: What were total sales last year?"
- "Show me the reload history for app xyz"

> **Note:** On-premise `qlik_insight_advisor` requires Insight Advisor Chat license enabled in QMC.

---

### 8. App Tools (1)

Create, update apps and manage data connections.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_generate_app` | Create or update a Qlik app with script and data connections | Cloud, On-Prem |

**Example prompts:**
- "Create a new app called Sales Report"
- "Update the load script for app xyz"

#### Cloud Workflow

On Qlik Cloud, `qlik_generate_app` uses REST APIs to create apps and trigger reloads asynchronously.

**Cloud Example Prompts:**

| What you say | What happens |
|--------------|--------------|
| "Create a Qlik app with sample sales data" | Creates app with inline LOAD script |
| "Create a new app called 'Dashboard' and load this data..." | Creates app in personal space |
| "Update the load script for app abc-123" | Updates existing app's script |

**Typical Cloud Workflow:**

1. **Create app with inline data:**
   ```
   "Create a Qlik app called 'Sales Analysis' with sample data
   for products, regions, and sales amounts"
   ```

2. **Create app using existing dataset:**
   ```
   "Create a Qlik app that loads from the 'Sales.qvd' dataset
   in my Data space"
   ```

3. **Update existing app:**
   ```
   "Update app abc-123 with a new load script that adds
   a calculated field for profit margin"
   ```

**Cloud Data Connection Note:**
On Cloud, data connections are managed via the Qlik Cloud hub or Spaces. Use `qlik_search` with `types: ["dataconnection"]` to find existing connections, then reference them in your load script using `LIB CONNECT TO`.

---

#### On-Premise Workflow (Engine API)
On Qlik Sense Enterprise, the tool uses the Engine API via WebSocket (port 4747) with certificate authentication:

1. **Create App** - `Global.CreateApp()`
2. **Create Data Connection** (optional) - `Doc.CreateConnection()`
3. **Set Load Script** - `Doc.SetScript()`
4. **Execute Reload** - `Doc.DoReload()`
5. **Save App** - `Doc.DoSave()`

**On-Premise Example Prompts:**

| What you say | What happens |
|--------------|--------------|
| "List available ODBC data sources on the server" | Lists all DSNs configured on the Qlik server |
| "Show me the data connections in app abc-123" | Lists all connections in the specified app |
| "Create a Qlik app with sample sales data" | Creates app with inline LOAD script |
| "Create an app that loads data from C:\Data\sales.csv" | Creates folder connection + app |
| "Create an app connected to SQL Server DSN 'MySQLServer'" | Creates ODBC connection + app |

**Typical On-Premise Workflow:**

1. **Discover data sources:**
   ```
   "What ODBC data sources are available on the Qlik server?"
   ```

2. **Explore existing app connections:**
   ```
   "List the data connections in the Sales Dashboard app"
   ```

3. **Create app with data:**
   ```
   "Create a new Qlik app called 'Customer Analysis' that connects to
   the folder C:\QlikData and loads customers.csv"
   ```

**Discovery Parameters:**
```json
// List available ODBC data sources on the server
{ "listOdbcDsns": true }

// List connections in an existing app
{ "appId": "abc-123", "listConnections": true }
```

**On-Premise Data Connection Examples:**

*Folder Connection:*
```json
{
  "appName": "SalesReport",
  "dataConnection": {
    "connectionName": "SalesData",
    "connectionType": "folder",
    "connectionString": "C:\\Data\\Sales\\"
  },
  "loadScript": "LOAD * FROM [lib://SalesData/sales.csv] (txt, codepage is 1252, embedded labels, delimiter is ',', msq);"
}
```

*ODBC Connection:*
```json
{
  "appName": "SQLReport",
  "dataConnection": {
    "connectionName": "SQLServer",
    "connectionType": "ODBC",
    "connectionString": "DSN=MyDSN",
    "username": "user",
    "password": "pass"
  },
  "loadScript": "LIB CONNECT TO 'SQLServer';\nSQL SELECT * FROM Sales;"
}
```

> **Note:** On-premise uses Engine API (port 4747) with certificate auth. Ensure certificates are properly exported from QMC.

---

### 9. Automation Tools (4) - Cloud Only

Manage automations.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_automation_list` | List all automations | Cloud |
| `qlik_automation_get_details` | Get automation details | Cloud |
| `qlik_automation_run` | Execute an automation | Cloud |
| `qlik_automation_list_runs` | List automation runs | Cloud |

**Example prompts:**
- "List all automations"
- "Run the daily ETL automation"
- "Show me the run history for automation xyz"

---

### 10. Alerts Tools (4) - Cloud Only

Data alerting and notifications.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_alert_list` | List all data alerts | Cloud |
| `qlik_alert_get` | Get alert details | Cloud |
| `qlik_alert_trigger` | Manually trigger an alert | Cloud |
| `qlik_alert_delete` | Delete an alert | Cloud |

**Example prompts:**
- "List all data alerts"
- "Show me the details of alert xyz"
- "Trigger the inventory alert"

---

### 11. Qlik Answers Tools (3) - Cloud Only

AI assistants with Q&A capabilities.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_answers_list_assistants` | List AI assistants | Cloud |
| `qlik_answers_get_assistant` | Get assistant details | Cloud |
| `qlik_answers_ask_question` | Ask a question to an assistant | Cloud |

**Example prompts:**
- "List all Qlik Answers assistants"
- "Show me the details of the Sales Assistant"
- "Ask the Sales Assistant: What were our top products last quarter?"

---

### 12. AutoML Tools (4) - Cloud Only

Machine learning experiments and deployments.

| Tool | Description | Platforms |
|------|-------------|-----------|
| `qlik_automl_get_experiments` | List all experiments | Cloud |
| `qlik_automl_get_experiment` | Get experiment details | Cloud |
| `qlik_automl_list_deployments` | List deployments | Cloud |
| `qlik_automl_get_deployment` | Get deployment details | Cloud |

**Example prompts:**
- "List all AutoML experiments"
- "Show me the deployments"
- "Get details for experiment xyz"

---

## Usage Examples

### Basic Queries

```
You: "Check the health of my Qlik Cloud tenant"
Claude: [Uses qlik_health_check] Your tenant is healthy...

You: "List all spaces"
Claude: [Uses qlik_get_spaces_catalog] Found 57 spaces...

You: "Search for users named John"
Claude: [Uses qlik_search_users] Found 3 users matching 'John'...
```

### Data Analysis

```
You: "Analyze the data model for my Sales Dashboard app"
Claude: [Uses qlik_analyze_data_model] The app has 5 tables,
       45 fields, with 1.2M rows in the main fact table...

You: "Select USA in the Country field, then show me the current selections"
Claude: [Uses qlik_apply_selections, qlik_get_current_selections]
       Selection applied. Current selections: Country = USA
```

### Reload Management

```
You: "Show me all currently running reloads"
Claude: [Uses qlik_monitor_active_reloads] 2 reloads in progress...

You: "Reload the Finance Dashboard"
Claude: [Uses qlik_trigger_app_reload] Reload started. Task ID: xyz...

You: "Check the reload history for that app"
Claude: [Uses qlik_get_app_reload_history] Last 5 reloads shown...
```

### AI/ML Features

```
You: "List all Qlik Answers assistants"
Claude: [Uses qlik_answers_list_assistants] Found 3 assistants...

You: "Ask the Sales Assistant: What were our top products last quarter?"
Claude: [Uses qlik_answers_ask_question] Based on the data,
       your top 5 products were...

You: "List AutoML experiments"
Claude: [Uses qlik_automl_get_experiments] Found 2 experiments...
```

---

## Platform Support

### Qlik Cloud
All 34 tools are available on Qlik Cloud.

### Qlik Sense Enterprise (On-Premise)
17 tools work on-premise. Cloud-only features return informative messages:

```json
{
  "success": false,
  "error": "This feature is only available on Qlik Cloud",
  "platform": "on-premise",
  "suggestion": "Alternative approach for on-premise..."
}
```

#### Cloud-Only Features (16 tools)
- Qlik Answers (2 tools)
- AutoML (4 tools)
- Data Alerts (4 tools)
- Automation (4 tools)
- Lineage (1 tool)
- Dataset Details (1 tool)

#### On-Premise Equivalents
| Cloud Feature | On-Premise Alternative |
|---------------|----------------------|
| Spaces | Streams (via QRS `/qrs/stream`) |
| Items API | QRS App API (`/qrs/app`) |
| Cloud Reloads | QRS Reload Tasks (`/qrs/reloadtask`) |
| Insight Advisor | NL Query API (`/api/v1/nl/query`) |
| App Create/Script | Engine API (`Global.CreateApp`, `Doc.SetScript`, `Doc.DoReload`) |
| Data Connections | Engine API (`Doc.CreateConnection`, `Doc.GetConnections`) |
| ODBC Discovery | Engine API (`Global.GetOdbcDsns`) |

---

## Testing

### Quick Smoke Test

```bash
export QLIK_TENANT_URL=https://your-tenant.qlikcloud.com
export QLIK_API_KEY=your-api-key
node test-cloud-quick.cjs
```

### Full Handler Test

```bash
node test-mcp-handlers.mjs
```

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `QLIK_TENANT_URL` | Yes | Qlik Cloud URL or Qlik Sense Enterprise server URL |
| `QLIK_DEPLOYMENT` | No | `cloud` (default) or `on-premise` |

**For Qlik Cloud:**

| Variable | Required | Description |
|----------|----------|-------------|
| `QLIK_API_KEY` | Yes | API key from Qlik Cloud hub |

**For Qlik Sense Enterprise (On-Premise):**

| Variable | Required | Description |
|----------|----------|-------------|
| `QLIK_CERT_PATH` | Yes | **Folder** containing `client.pem`, `client_key.pem`, `root.pem` |
| `QLIK_USER_DIRECTORY` | Yes | Windows domain (e.g., `COMPANY`) |
| `QLIK_USER_ID` | Yes | Username to act as (e.g., `admin`) |
| `QLIK_VIRTUAL_PROXY` | No | Virtual proxy prefix (if configured) |

---

## Troubleshooting

### "Tool not found" Error
Ensure the MCP server is running and Claude Desktop was restarted after configuration.

### Authentication Errors

**Qlik Cloud:**
- Verify your API key is valid and not expired
- Ensure the API key has appropriate permissions

**Qlik Sense Enterprise (On-Premise):**
- Verify certificate paths are correct and files exist
- Ensure certificates were exported with the private key
- Check that the certificate hasn't expired
- Verify the machine name in the certificate matches your setup

### "Cloud-only feature" Message
Some tools are only available on Qlik Cloud. The error message will suggest alternatives.

### Connection Timeout
Check network connectivity to your Qlik server. Ensure firewalls allow the connection.

### Empty MCP Server / Tools Not Showing

If Claude Desktop shows empty MCP server with no tools:

1. **Check if dist/ folder exists:**
   ```powershell
   dir C:\qlik-claude-mcp-main\dist\
   ```
   If not, run `npm run build` first.

2. **Check MCP server logs:**
   ```powershell
   type "$env:APPDATA\Claude\logs\mcp-server-qlik-mcp-os.log"
   ```

3. **Fully restart Claude Desktop:**
   - Close Claude Desktop
   - Open Task Manager (Ctrl+Shift+Esc)
   - Find "Claude" and click **End Task**
   - Reopen Claude Desktop

4. **Verify config file location:**
   ```powershell
   type "$env:APPDATA\Claude\claude_desktop_config.json"
   ```

### Server Hangs or Slow Response

If the server hangs or responds slowly, use optimized config with memory settings:

```json
{
  "mcpServers": {
    "qlik-mcp-os": {
      "command": "node",
      "args": [
        "--max-old-space-size=4096",
        "C:\\qlik-claude-mcp-main\\dist\\index.js"
      ],
      "env": {
        "QLIK_TENANT_URL": "https://your-tenant.qlikcloud.com",
        "QLIK_API_KEY": "your-api-key",
        "NODE_ENV": "production"
      }
    }
  }
}
```

### "Cannot find module" Error

This means `npm run build` was not executed:

```powershell
cd C:\qlik-claude-mcp-main
npm install
npm run build
```

Then restart Claude Desktop.

---

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Claude Desktop │────▶│   MCP Server    │────▶│   Qlik Cloud    │
│                 │     │                 │     │   (REST APIs)   │
│  Natural Lang   │◀────│  33 Tools       │◀────│                 │
│  Interface      │     │  12 Categories  │     ├─────────────────┤
└─────────────────┘     └─────────────────┘     │ Qlik Sense Ent. │
                                                │ (QRS + Engine)  │
                                                └─────────────────┘
```

**Cloud:** REST APIs (`/api/v1/*`) with API key authentication

**On-Premise:**
- QRS API (port 4242) - Management operations
- Engine API (port 4747) - App creation, scripts, data connections via WebSocket

---

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `npm test`
5. Submit a pull request

---

## License

MIT License - See LICENSE file for details.

---

## Support

- **Issues**: [GitHub Issues](https://github.com/undsoul/qlik-claude-mcp/issues)
- **Documentation**: See `/docs` folder
- **Qlik Community**: [community.qlik.com](https://community.qlik.com)

---

*Built with the Model Context Protocol (MCP) for seamless AI-analytics integration.*
