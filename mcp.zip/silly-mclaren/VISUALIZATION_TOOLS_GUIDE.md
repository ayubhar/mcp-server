# Visualization, Field, and Master Items Tools Guide

Complete guide for using the Qlik Cloud visualization, field operations, and master items management tools via the Qlik MCP Server.

---

## Table of Contents

1. [Overview](#overview)
2. [Tool Categories](#tool-categories)
3. [Visualization Tools](#visualization-tools)
4. [Field Tools](#field-tools)
5. [Master Items Tools](#master-items-tools)
6. [Usage Examples](#usage-examples)
7. [Technical Architecture](#technical-architecture)
8. [API Reference](#api-reference)
9. [Troubleshooting](#troubleshooting)

---

## Overview

This suite of **18 tools** enables comprehensive management of visualizations, fields, and master items in Qlik Cloud applications using the Engine API via enigma.js.

### Key Capabilities

- **Visualization Management** (5 tools): Create, list, get, update, and delete visualizations (straight tables/sn-table)
- **Field Operations** (3 tools): List fields, get field values, and retrieve field metadata
- **Master Items** (10 tools): Full CRUD operations for master dimensions and measures

### Platform Support

**Qlik Cloud Only** - All tools use the Engine API via WebSocket connections and are currently only available on Qlik Cloud.

### Prerequisites

- Qlik Cloud tenant with API access
- API key with appropriate permissions
- AppId and SheetId for visualization operations
- Understanding of Qlik data model (fields, dimensions, measures)

---

## Tool Categories

### 1. Visualization Tools (5 tools)

| Tool Name | Purpose | Key Parameters |
|-----------|---------|----------------|
| `qlik_visualization_create` | Create straight table on a sheet | appId, sheetId, title, dimensions, measures, position |
| `qlik_visualization_list` | List all visualizations on a sheet | appId, sheetId |
| `qlik_visualization_get` | Get details of a specific visualization | appId, sheetId, objectId |
| `qlik_visualization_update` | Update visualization properties | appId, sheetId, objectId, updates |
| `qlik_visualization_delete` | Delete visualization from sheet | appId, sheetId, objectId |

### 2. Field Tools (3 tools)

| Tool Name | Purpose | Key Parameters |
|-----------|---------|----------------|
| `qlik_field_list` | List all fields in an app | appId, includeSystem, includeTags |
| `qlik_field_values` | Get distinct values for a field | appId, fieldName, limit, searchTerm |
| `qlik_field_info` | Get metadata about a field | appId, fieldName |

### 3. Master Items Tools (10 tools)

#### Master Dimensions (5 tools)

| Tool Name | Purpose | Key Parameters |
|-----------|---------|----------------|
| `qlik_master_dimension_create` | Create reusable dimension | appId, field, label, description, tags |
| `qlik_master_dimension_list` | List all master dimensions | appId |
| `qlik_master_dimension_get` | Get dimension details | appId, dimensionId |
| `qlik_master_dimension_update` | Update dimension properties | appId, dimensionId, updates |
| `qlik_master_dimension_delete` | Delete master dimension | appId, dimensionId |

#### Master Measures (5 tools)

| Tool Name | Purpose | Key Parameters |
|-----------|---------|----------------|
| `qlik_master_measure_create` | Create reusable measure | appId, expression, label, description, tags, numberFormat |
| `qlik_master_measure_list` | List all master measures | appId |
| `qlik_master_measure_get` | Get measure details | appId, measureId |
| `qlik_master_measure_update` | Update measure properties | appId, measureId, updates |
| `qlik_master_measure_delete` | Delete master measure | appId, measureId |

---

## Visualization Tools

### 1. Create Visualization

**Tool**: `qlik_visualization_create`

Creates a new straight table (sn-table) visualization on a sheet with specified dimensions and measures.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "sheetId": "string (required)",
  "title": "string (required)",
  "visualizationType": "sn-table | straight-table (default: sn-table)",
  "dimensions": [
    {
      "field": "string (required)",
      "label": "string (optional)"
    }
  ],
  "measures": [
    {
      "expression": "string (required)",
      "label": "string (optional)",
      "format": {
        "type": "auto | number | currency | percent",
        "decimals": "number"
      }
    }
  ],
  "position": {
    "x": "number (0-23, default: 0)",
    "y": "number (0-11, default: 0)",
    "width": "number (1-24, default: 12)",
    "height": "number (1-12, default: 6)"
  }
}
```

**Example**:

```json
{
  "appId": "abc123",
  "sheetId": "xyz789",
  "title": "Sales by Region",
  "visualizationType": "sn-table",
  "dimensions": [
    { "field": "Region", "label": "Sales Region" },
    { "field": "Country" }
  ],
  "measures": [
    {
      "expression": "Sum(Sales)",
      "label": "Total Sales",
      "format": { "type": "currency", "decimals": 2 }
    },
    {
      "expression": "Avg(Price)",
      "label": "Average Price"
    }
  ],
  "position": {
    "x": 0,
    "y": 0,
    "width": 12,
    "height": 8
  }
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "objectId": "hJpqKz",
  "visualization": {
    "id": "hJpqKz",
    "type": "sn-table",
    "title": "Sales by Region",
    "dimensions": 2,
    "measures": 2,
    "position": { "x": 0, "y": 0, "width": 12, "height": 8 }
  },
  "message": "Visualization created successfully on sheet xyz789",
  "timestamp": "2025-12-24T10:30:00.000Z"
}
```

### 2. List Visualizations

**Tool**: `qlik_visualization_list`

Lists all visualizations on a specific sheet.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "sheetId": "string (required)"
}
```

**Example**:

```json
{
  "appId": "abc123",
  "sheetId": "xyz789"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "visualizations": [
    {
      "id": "hJpqKz",
      "type": "sn-table",
      "title": "Sales by Region",
      "dimensions": 2,
      "measures": 2,
      "bounds": { "x": 0, "y": 0, "width": 12, "height": 8 }
    },
    {
      "id": "mNqrSt",
      "type": "sn-table",
      "title": "Product Analysis",
      "dimensions": 1,
      "measures": 3,
      "bounds": { "x": 12, "y": 0, "width": 12, "height": 8 }
    }
  ],
  "totalCount": 2,
  "timestamp": "2025-12-24T10:35:00.000Z"
}
```

### 3. Delete Visualization

**Tool**: `qlik_visualization_delete`

Removes a visualization from a sheet.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "sheetId": "string (required)",
  "objectId": "string (required)"
}
```

**Example**:

```json
{
  "appId": "abc123",
  "sheetId": "xyz789",
  "objectId": "hJpqKz"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "message": "Visualization hJpqKz deleted from sheet xyz789",
  "timestamp": "2025-12-24T10:40:00.000Z"
}
```

---

## Field Tools

### 1. List Fields

**Tool**: `qlik_field_list`

Lists all fields in an app's data model.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "includeSystem": "boolean (default: false)",
  "includeTags": "boolean (default: true)"
}
```

**Example**:

```json
{
  "appId": "abc123",
  "includeSystem": false,
  "includeTags": true
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "fields": [
    {
      "name": "Region",
      "tags": ["$ascii", "$text"],
      "totalCount": 5,
      "isSystem": false,
      "isHidden": false,
      "isKey": false
    },
    {
      "name": "Sales",
      "tags": ["$numeric", "$integer"],
      "totalCount": 1000,
      "isSystem": false,
      "isHidden": false,
      "isKey": false
    }
  ],
  "totalFields": 2,
  "timestamp": "2025-12-24T10:45:00.000Z"
}
```

### 2. Get Field Values

**Tool**: `qlik_field_values`

Retrieves distinct values for a specific field.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "fieldName": "string (required)",
  "limit": "number (default: 100, max: 10000)",
  "searchTerm": "string (optional)"
}
```

**Example**:

```json
{
  "appId": "abc123",
  "fieldName": "Region",
  "limit": 50,
  "searchTerm": "North"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "fieldName": "Region",
  "values": [
    {
      "text": "North America",
      "isNumeric": false,
      "number": null
    },
    {
      "text": "North Europe",
      "isNumeric": false,
      "number": null
    }
  ],
  "totalCount": 2,
  "cardinalCount": 5,
  "timestamp": "2025-12-24T10:50:00.000Z"
}
```

### 3. Get Field Info

**Tool**: `qlik_field_info`

Retrieves metadata about a field including cardinality, tags, and key status.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "fieldName": "string (required)"
}
```

**Example**:

```json
{
  "appId": "abc123",
  "fieldName": "Sales"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "field": {
    "name": "Sales",
    "cardinalRatio": {
      "numerator": 1000,
      "denominator": 1000
    },
    "totalCount": 1000,
    "tags": ["$numeric", "$integer"],
    "isSystem": false,
    "isHidden": false,
    "isKey": false,
    "isSemantic": false
  },
  "timestamp": "2025-12-24T10:55:00.000Z"
}
```

---

## Master Items Tools

### Master Dimensions

#### 1. Create Master Dimension

**Tool**: `qlik_master_dimension_create`

Creates a reusable dimension in the app library.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "field": "string (required)",
  "label": "string (required)",
  "description": "string (optional)",
  "tags": ["string"] (optional)
}
```

**Example**:

```json
{
  "appId": "abc123",
  "field": "Region",
  "label": "Sales Region",
  "description": "Geographic sales regions",
  "tags": ["geography", "sales"]
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "dimensionId": "fGhIjK",
  "dimension": {
    "id": "fGhIjK",
    "field": "Region",
    "label": "Sales Region",
    "description": "Geographic sales regions",
    "tags": ["geography", "sales"]
  },
  "message": "Master dimension 'Sales Region' created successfully",
  "timestamp": "2025-12-24T11:00:00.000Z"
}
```

#### 2. List Master Dimensions

**Tool**: `qlik_master_dimension_list`

Lists all master dimensions in an app.

**Input Schema**:

```json
{
  "appId": "string (required)"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "dimensions": [
    {
      "id": "fGhIjK",
      "title": "Sales Region",
      "field": "Region",
      "tags": ["geography", "sales"]
    },
    {
      "id": "lMnOpQ",
      "title": "Product Category",
      "field": "Category",
      "tags": ["product"]
    }
  ],
  "totalCount": 2,
  "timestamp": "2025-12-24T11:05:00.000Z"
}
```

#### 3. Delete Master Dimension

**Tool**: `qlik_master_dimension_delete`

Deletes a master dimension from the app library.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "dimensionId": "string (required)"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "message": "Master dimension fGhIjK deleted successfully",
  "timestamp": "2025-12-24T11:10:00.000Z"
}
```

### Master Measures

#### 1. Create Master Measure

**Tool**: `qlik_master_measure_create`

Creates a reusable measure in the app library.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "expression": "string (required)",
  "label": "string (required)",
  "description": "string (optional)",
  "tags": ["string"] (optional),
  "numberFormat": {
    "type": "auto | number | currency | percent",
    "decimals": "number"
  } (optional)
}
```

**Example**:

```json
{
  "appId": "abc123",
  "expression": "Sum(Sales)",
  "label": "Total Sales",
  "description": "Sum of all sales",
  "tags": ["kpi", "sales"],
  "numberFormat": {
    "type": "currency",
    "decimals": 2
  }
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "measureId": "rStUvW",
  "measure": {
    "id": "rStUvW",
    "expression": "Sum(Sales)",
    "label": "Total Sales",
    "description": "Sum of all sales",
    "tags": ["kpi", "sales"],
    "numberFormat": {
      "type": "currency",
      "decimals": 2
    }
  },
  "message": "Master measure 'Total Sales' created successfully",
  "timestamp": "2025-12-24T11:15:00.000Z"
}
```

#### 2. List Master Measures

**Tool**: `qlik_master_measure_list`

Lists all master measures in an app.

**Input Schema**:

```json
{
  "appId": "string (required)"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "measures": [
    {
      "id": "rStUvW",
      "title": "Total Sales",
      "expression": "Sum(Sales)",
      "tags": ["kpi", "sales"]
    },
    {
      "id": "xYzAbC",
      "title": "Average Price",
      "expression": "Avg(Price)",
      "tags": ["kpi", "pricing"]
    }
  ],
  "totalCount": 2,
  "timestamp": "2025-12-24T11:20:00.000Z"
}
```

#### 3. Delete Master Measure

**Tool**: `qlik_master_measure_delete`

Deletes a master measure from the app library.

**Input Schema**:

```json
{
  "appId": "string (required)",
  "measureId": "string (required)"
}
```

**Response**:

```json
{
  "success": true,
  "platform": "cloud",
  "message": "Master measure rStUvW deleted successfully",
  "timestamp": "2025-12-24T11:25:00.000Z"
}
```

---

## Usage Examples

### Example 1: Create Complete Dashboard

**Step 1: Create master dimensions**

```json
// Create Region dimension
{
  "tool": "qlik_master_dimension_create",
  "appId": "abc123",
  "field": "Region",
  "label": "Sales Region",
  "tags": ["geography"]
}

// Create Product dimension
{
  "tool": "qlik_master_dimension_create",
  "appId": "abc123",
  "field": "ProductName",
  "label": "Product",
  "tags": ["product"]
}
```

**Step 2: Create master measures**

```json
// Create Total Sales measure
{
  "tool": "qlik_master_measure_create",
  "appId": "abc123",
  "expression": "Sum(Sales)",
  "label": "Total Sales",
  "tags": ["kpi"],
  "numberFormat": { "type": "currency", "decimals": 2 }
}

// Create Profit Margin measure
{
  "tool": "qlik_master_measure_create",
  "appId": "abc123",
  "expression": "Sum(Profit) / Sum(Sales)",
  "label": "Profit Margin %",
  "tags": ["kpi"],
  "numberFormat": { "type": "percent", "decimals": 1 }
}
```

**Step 3: Create visualization using master items**

```json
{
  "tool": "qlik_visualization_create",
  "appId": "abc123",
  "sheetId": "xyz789",
  "title": "Sales Performance by Region",
  "dimensions": [
    { "field": "Region", "label": "Sales Region" }
  ],
  "measures": [
    { "expression": "Sum(Sales)", "label": "Total Sales" },
    { "expression": "Sum(Profit) / Sum(Sales)", "label": "Profit Margin %" }
  ],
  "position": { "x": 0, "y": 0, "width": 24, "height": 10 }
}
```

### Example 2: Explore Data Model

**Step 1: List all fields**

```json
{
  "tool": "qlik_field_list",
  "appId": "abc123",
  "includeSystem": false,
  "includeTags": true
}
```

**Step 2: Get field values**

```json
{
  "tool": "qlik_field_values",
  "appId": "abc123",
  "fieldName": "Region",
  "limit": 100
}
```

**Step 3: Get field metadata**

```json
{
  "tool": "qlik_field_info",
  "appId": "abc123",
  "fieldName": "Sales"
}
```

### Example 3: Update Visualization

**Step 1: List visualizations to find objectId**

```json
{
  "tool": "qlik_visualization_list",
  "appId": "abc123",
  "sheetId": "xyz789"
}
```

**Step 2: Delete old visualization**

```json
{
  "tool": "qlik_visualization_delete",
  "appId": "abc123",
  "sheetId": "xyz789",
  "objectId": "hJpqKz"
}
```

**Step 3: Create new visualization with updated design**

```json
{
  "tool": "qlik_visualization_create",
  "appId": "abc123",
  "sheetId": "xyz789",
  "title": "Updated Sales Analysis",
  "dimensions": [
    { "field": "Region" },
    { "field": "Quarter" }
  ],
  "measures": [
    { "expression": "Sum(Sales)", "label": "Sales" }
  ],
  "position": { "x": 0, "y": 0, "width": 24, "height": 12 }
}
```

---

## Technical Architecture

### Engine API Integration

All tools use the Qlik Engine API via enigma.js:

```typescript
// WebSocket connection to Qlik Cloud
const wsUrl = `wss://${hostname}/app/${appId}`;

const session = enigma.create({
  schema,  // enigma.js schema (12.20.0)
  url: wsUrl,
  createSocket: (url) => new WebSocket(url, {
    headers: { 'Authorization': `Bearer ${apiKey}` },
    rejectUnauthorized: false
  })
});

const global = await session.open();
const doc = await global.openDoc(appId);

// Perform operations...
await session.close();
```

### Visualization Creation Process

1. **Open Engine Session**: Connect to app via WebSocket
2. **Get Sheet Object**: `doc.getObject(sheetId)`
3. **Build HyperCube Definition**:
   ```typescript
   const qHyperCubeDef = {
     qDimensions: dimensions.map(d => ({
       qDef: { qFieldDefs: [d.field], qFieldLabels: [d.label] }
     })),
     qMeasures: measures.map(m => ({
       qDef: { qDef: m.expression, qLabel: m.label }
     })),
     qInitialDataFetch: [{ qWidth: 10, qHeight: 100 }]
   };
   ```
4. **Create Visualization**: `sheet.createChild(vizProperties)`
5. **Update Sheet Cells**: Add visualization to sheet's cells array
6. **Save**: `doc.doSave()`

### Master Items Implementation

**Master Dimensions**:
```typescript
const dimension = await doc.createDimension({
  qInfo: { qType: 'dimension', qId: '' },
  qDim: {
    qFieldDefs: [field],
    qFieldLabels: [label]
  },
  qMetaDef: { title: label, description, tags }
});
```

**Master Measures**:
```typescript
const measure = await doc.createMeasure({
  qInfo: { qType: 'measure', qId: '' },
  qMeasure: {
    qLabel: label,
    qDef: expression,
    qNumFormat: numberFormat
  },
  qMetaDef: { title: label, description, tags }
});
```

### Field Operations

**List Fields**:
```typescript
const fieldList = await doc.getFieldList();
return fieldList.qFieldList.qItems;
```

**Get Field Values**:
```typescript
const field = await doc.getField(fieldName);
const data = await field.getData(0, limit, 10000);
return data.qMatrix.map(row => ({
  text: row[0].qText,
  isNumeric: row[0].qIsNumeric,
  number: row[0].qNum
}));
```

---

## API Reference

### Engine API Methods Used

#### Document Methods
- `doc.getObject(objectId)` - Get sheet or object
- `doc.createDimension(props)` - Create master dimension
- `doc.createMeasure(props)` - Create master measure
- `doc.destroyObject(objectId)` - Delete object
- `doc.getFieldList()` - List all fields
- `doc.getField(fieldName)` - Get field object
- `doc.doSave()` - Save changes

#### Sheet Methods
- `sheet.createChild(props)` - Create visualization on sheet
- `sheet.getProperties()` - Get sheet properties
- `sheet.setProperties(props)` - Update sheet properties
- `sheet.getLayout()` - Get current layout

#### Field Methods
- `field.getData(start, count, freq)` - Get field values
- `field.getCardinal()` - Get distinct value count

### HyperCube Structure

```typescript
interface QHyperCubeDef {
  qDimensions: Array<{
    qDef: {
      qFieldDefs: string[];
      qFieldLabels?: string[];
      qSortCriterias?: Array<{
        qSortByNumeric?: -1 | 0 | 1;
        qSortByAscii?: -1 | 0 | 1;
      }>;
    };
  }>;
  qMeasures: Array<{
    qDef: {
      qDef: string;  // Expression
      qLabel?: string;
      qNumFormat?: {
        qType: 'U' | 'F' | 'M' | 'D' | 'IV';
        qnDec?: number;
        qUseThou?: 0 | 1;
      };
    };
  }>;
  qInitialDataFetch: Array<{
    qWidth: number;
    qHeight: number;
  }>;
}
```

---

## Troubleshooting

### Common Issues

#### 1. "Visualization not appearing on sheet"

**Problem**: Visualization created but not visible in Qlik Sense.

**Solution**:
- Check that position coordinates are within sheet bounds (x: 0-23, y: 0-11)
- Verify sheet was saved (`doc.doSave()` was called)
- Refresh the sheet in Qlik Sense
- Check visualization was added to sheet's `cells` array

#### 2. "Field not found"

**Problem**: Field operations fail with "field not found" error.

**Solution**:
- Use `qlik_field_list` to get exact field names (case-sensitive)
- Ensure app has been reloaded with data
- Check field is not a system field (prefix with `$`)

#### 3. "Cannot create master dimension/measure"

**Problem**: Master item creation fails.

**Solution**:
- Verify field name exists in data model
- Check expression syntax for measures
- Ensure labels don't contain special characters
- Verify you have edit permissions on the app

#### 4. "WebSocket connection failed"

**Problem**: Engine API connection errors.

**Solution**:
- Verify API key is valid and not expired
- Check tenant URL is correct format
- Ensure app ID is valid and accessible
- Verify firewall allows WebSocket connections

#### 5. "HyperCube definition error"

**Problem**: Visualization creation fails with hypercube errors.

**Solution**:
- Verify all dimension fields exist in data model
- Check measure expressions are valid Qlik syntax
- Ensure at least one dimension and one measure are provided
- Validate number format settings

### Debug Logging

All handlers include detailed error logging:

```typescript
console.error(`[VisualizationHandlers] visualization_create called (platform: ${platform})`);
console.error('[VisualizationHandlers] Args:', JSON.stringify(args));
console.error('[VisualizationHandlers] Error:', error);
```

**View logs**:
- macOS: `~/Library/Logs/Claude/mcp-server-qlik-mcp-*.log`
- Windows: `%APPDATA%\Claude\logs\mcp-server-qlik-mcp-*.log`

### Testing Checklist

Before using in production:

- [ ] Test field listing to verify data model access
- [ ] Create test master dimension and measure
- [ ] Create simple visualization with 1 dimension and 1 measure
- [ ] Verify visualization appears on sheet
- [ ] Test field values retrieval
- [ ] Test master item deletion
- [ ] Verify session cleanup (no orphaned connections)

---

## Best Practices

### 1. Master Items First

Always create master dimensions and measures before building visualizations:

```
1. Create master dimensions → 2. Create master measures → 3. Create visualizations
```

Benefits:
- Reusability across multiple sheets
- Consistent definitions
- Easier maintenance
- Better governance

### 2. Field Discovery

Use field tools to understand the data model:

```
1. List all fields → 2. Get field values → 3. Analyze field info → 4. Build visualizations
```

### 3. Position Management

Plan visualization layouts on 24x12 grid:

```
Full width: { x: 0, y: 0, width: 24, height: 8 }
Half width left: { x: 0, y: 0, width: 12, height: 8 }
Half width right: { x: 12, y: 0, width: 12, height: 8 }
Quarter: { x: 0, y: 0, width: 6, height: 6 }
```

### 4. Error Handling

Always check response `success` field:

```typescript
const result = await qlik_visualization_create({...});

if (!result.success) {
  console.error('Visualization creation failed:', result.error);
  // Handle error
}
```

### 5. Session Management

Engine API sessions are automatically managed:
- Session opens at start of operation
- Operations execute
- Session closes automatically (even on error)

No manual session management required.

---

## Related Documentation

- **Sheet Tools Guide**: `SHEET_TOOLS_GUIDE.md`
- **Main Documentation**: `CLAUDE.md`
- **Developer Guide**: `DEVELOPER_GUIDE.md`
- **Qlik Engine API**: https://help.qlik.com/en-US/sense-developer/
- **enigma.js**: https://github.com/qlik-oss/enigma.js/

---

**Last Updated**: 2025-12-24
**Version**: 1.0.0
**Tools**: 18 (5 visualization + 3 field + 10 master items)
