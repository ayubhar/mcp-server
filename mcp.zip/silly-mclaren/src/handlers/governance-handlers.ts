/**
 * Governance Handlers - Connect MCP tools to governance services
 * Updated with platform support for Cloud and On-Premise
 */

import { ApiClient } from '../utils/api-client.js';
import { CacheManager } from '../utils/cache-manager.js';

/**
 * Handler for get_tenant_info tool
 * Get basic tenant information
 */
export async function handleGetTenantInfo(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[GovernanceHandlers] get_tenant_info called (platform: ${platform})`);

  try {
    let tenantInfo: any;

    if (platform === 'on-premise') {
      // On-Premise: Get server about info
      const aboutResponse = await apiClient.makeRequest('/qrs/about');
      tenantInfo = {
        platform: 'on-premise',
        serverVersion: aboutResponse.buildVersion,
        serverNodeId: aboutResponse.serverNodeId,
        addOns: aboutResponse.addOns,
        schemaPath: aboutResponse.schemaPath
      };

      // Also get license info
      try {
        const licenseResponse = await apiClient.makeRequest('/qrs/license');
        tenantInfo.license = {
          serial: licenseResponse.serial,
          name: licenseResponse.name,
          organization: licenseResponse.organization,
          product: licenseResponse.product,
          numberOfCores: licenseResponse.numberOfCores,
          lef: licenseResponse.lef
        };
      } catch (e) {
        console.error('[GovernanceHandlers] Error fetching QRS license:', e);
      }
    } else {
      // Cloud: Get user/tenant info
      tenantInfo = await apiClient.makeRequest('/api/v1/users/me');
    }

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: true,
          platform,
          tenantInfo,
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[GovernanceHandlers] Error in get_tenant_info:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for get_user_info tool
 * Get detailed user information
 */
export async function handleGetUserInfo(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[GovernanceHandlers] get_user_info called (platform: ${platform})`);

  try {
    if (!args?.userId) {
      throw new Error('User ID is required');
    }

    let userInfo: any;

    if (platform === 'on-premise') {
      // On-Premise: Get user from QRS
      // Check if userId looks like a GUID (contains hyphens and is 36 chars)
      const isGuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.userId);

      let userResponse: any;

      if (isGuid) {
        // Direct lookup by GUID
        userResponse = await apiClient.makeRequest(`/qrs/user/${args.userId}`);
      } else {
        // Search by userId (username) using filter
        // Format: userId eq 'username' (exact match)
        const filter = `userId eq '${args.userId}'`;
        const encodedFilter = encodeURIComponent(filter);
        const users = await apiClient.makeRequest(`/qrs/user?filter=${encodedFilter}`);

        if (!users || users.length === 0) {
          throw new Error(`User not found: ${args.userId}`);
        }
        userResponse = users[0];
      }

      userInfo = {
        id: userResponse.id,
        userId: userResponse.userId,
        userDirectory: userResponse.userDirectory,
        name: userResponse.name,
        roles: userResponse.roles || [],
        inactive: userResponse.inactive,
        removed: userResponse.removedExternally,
        createdDate: userResponse.createdDate,
        modifiedDate: userResponse.modifiedDate,
        platform: 'on-premise'
      };
    } else {
      // Cloud: Get user from Cloud API
      userInfo = await apiClient.makeRequest(`/api/v1/users/${args.userId}`);
    }

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: true,
          platform,
          userInfo,
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[GovernanceHandlers] Error in get_user_info:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for search_users tool
 * Search for users by name or email
 */
export async function handleSearchUsers(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[GovernanceHandlers] search_users called (platform: ${platform})`);

  try {
    if (!args?.query) {
      throw new Error('Search query is required');
    }

    let users: any[];
    let totalCount: number;

    if (platform === 'on-premise') {
      // On-Premise: Search users via QRS with filter
      // QRS uses 'so' (substring of) operator for partial matching, not 'like'
      // Valid operators: eq, ne, sw (starts with), ew (ends with), so (substring of)
      const filter = `name so '${args.query}' or userId so '${args.query}'`;
      const encodedFilter = encodeURIComponent(filter);
      const response = await apiClient.makeRequest(`/qrs/user?filter=${encodedFilter}`);
      const qrsUsers = response.data || response || [];

      users = qrsUsers.slice(0, args.limit || 50).map((user: any) => ({
        id: user.id,
        userId: user.userId,
        userDirectory: user.userDirectory,
        name: user.name,
        inactive: user.inactive,
        createdDate: user.createdDate
      }));
      totalCount = qrsUsers.length;
    } else {
      // Cloud: Use existing getUsers method
      const response = await apiClient.getUsers({
        search: args.query,
        limit: args.limit || 50
      });
      users = response.data || [];
      totalCount = response.totalCount || users.length;
    }

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: true,
          platform,
          query: args.query,
          users,
          totalCount,
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[GovernanceHandlers] Error in search_users:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for health_check tool
 * Check server status and service health
 */
export async function handleHealthCheck(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[GovernanceHandlers] health_check called (platform: ${platform})`);

  try {
    let healthData: any;

    if (platform === 'on-premise') {
      // On-Premise: Check QRS about endpoint
      healthData = await apiClient.makeRequest('/qrs/about');

      return {
        content: [{
          type: 'text',
          text: JSON.stringify({
            success: true,
            status: 'healthy',
            platform: 'on-premise',
            services: {
              qrs: 'operational',
              cache: cacheManager ? 'operational' : 'unavailable'
            },
            serverInfo: {
              version: healthData.buildVersion,
              nodeId: healthData.serverNodeId
            },
            timestamp: new Date().toISOString()
          }, null, 2)
        }]
      };
    }

    // Cloud: Check API connectivity
    healthData = await apiClient.makeRequest('/api/v1/users/me');

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: true,
          status: 'healthy',
          platform: 'cloud',
          services: {
            api: 'operational',
            cache: cacheManager ? 'operational' : 'unavailable'
          },
          timestamp: new Date().toISOString(),
          tenant: healthData.tenantId || 'unknown'
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[GovernanceHandlers] Error in health_check:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          status: 'unhealthy',
          platform,
          error: error instanceof Error ? error.message : String(error),
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for get_license_info tool (New)
 * Get license information
 */
export async function handleGetLicenseInfo(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[GovernanceHandlers] get_license_info called (platform: ${platform})`);

  try {
    let licenseInfo: any;

    if (platform === 'on-premise') {
      // On-Premise: Get license from QRS
      const licenseResponse = await apiClient.makeRequest('/qrs/license');
      licenseInfo = {
        platform: 'on-premise',
        serial: licenseResponse.serial,
        name: licenseResponse.name,
        organization: licenseResponse.organization,
        product: licenseResponse.product,
        numberOfCores: licenseResponse.numberOfCores,
        lef: licenseResponse.lef,
        isExpired: licenseResponse.isExpired,
        expiredReason: licenseResponse.expiredReason
      };

      // Get license access type info
      try {
        const accessTypes = await apiClient.makeRequest('/qrs/license/accesstypeinfo');
        licenseInfo.accessTypes = accessTypes;
      } catch (e) {
        // Access type info might not be available
      }
    } else {
      // Cloud: Get license overview
      licenseInfo = await apiClient.makeRequest('/api/v1/licenses/overview');
      licenseInfo.platform = 'cloud';
    }

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: true,
          platform,
          licenseInfo,
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[GovernanceHandlers] Error in get_license_info:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}
