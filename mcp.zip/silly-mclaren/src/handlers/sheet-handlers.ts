/**
 * Sheet Handlers - Qlik Cloud Sheet Management
 *
 * Handlers for sheet CRUD operations using Engine API.
 * All sheet operations are Cloud only.
 */

import { ApiClient } from '../utils/api-client.js';
import { CacheManager } from '../utils/cache-manager.js';
import { SheetService } from '../services/sheet-service.js';

/**
 * Handler for sheet_create tool
 * Create a new sheet in a Qlik Cloud app
 */
export async function handleSheetCreate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_create called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.createSheet(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_create:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for sheet_list tool
 * List all sheets in a Qlik Cloud app
 */
export async function handleSheetList(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_list called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.listSheets(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_list:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for sheet_get tool
 * Get detailed information about a specific sheet
 */
export async function handleSheetGet(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_get called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.getSheet(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_get:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for sheet_update tool
 * Update properties of an existing sheet
 */
export async function handleSheetUpdate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_update called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.updateSheet(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_update:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for sheet_delete tool
 * Delete a sheet from a Qlik Cloud app
 */
export async function handleSheetDelete(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_delete called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.deleteSheet(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_delete:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

/**
 * Handler for sheet_duplicate tool
 * Duplicate an existing sheet
 */
export async function handleSheetDuplicate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[SheetHandlers] sheet_duplicate called (platform: ${platform})`);

  // Cloud-only gate
  if (platform === 'on-premise') {
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: 'Sheet management via Engine API is only available on Qlik Cloud',
          platform: 'on-premise',
          suggestion: 'Use Qlik Management Console (QMC) or Qlik Sense Hub to manage sheets on-premise'
        }, null, 2)
      }]
    };
  }

  try {
    const sheetService = new SheetService(apiClient, cacheManager, platform, tenantUrl);
    const result = await sheetService.duplicateSheet(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          ...result,
          platform: 'cloud',
          timestamp: new Date().toISOString()
        }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[SheetHandlers] Error in sheet_duplicate:', error);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}
