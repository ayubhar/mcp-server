/**
 * Visualization Handlers - For visualization, field, and master items tools
 *
 * Handles all visualization-related operations including:
 * - Visualization management (sn-table)
 * - Field operations
 * - Master dimensions and measures
 *
 * Cloud only
 */

import { ApiClient } from '../utils/api-client.js';
import { CacheManager } from '../utils/cache-manager.js';
import { VisualizationService } from '../services/visualization-service.js';

const cloudOnlyError = {
  content: [{
    type: 'text',
    text: JSON.stringify({
      success: false,
      error: 'Visualization management via Engine API is only available on Qlik Cloud',
      platform: 'on-premise',
      suggestion: 'Use Qlik Sense Hub to create and manage visualizations on-premise'
    }, null, 2)
  }]
};

// ===== VISUALIZATION HANDLERS =====

export async function handleVisualizationCreate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] visualization_create called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.createVisualization(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleVisualizationDelete(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] visualization_delete called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.deleteVisualization(args.appId, args.sheetId, args.objectId);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

// ===== FIELD HANDLERS =====

export async function handleFieldList(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] field_list called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.listFields(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleFieldValues(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] field_values called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.getFieldValues(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

// ===== MASTER DIMENSION HANDLERS =====

export async function handleMasterDimensionCreate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_dimension_create called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.createMasterDimension(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleMasterDimensionList(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_dimension_list called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.listMasterDimensions(args.appId);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleMasterDimensionDelete(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_dimension_delete called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.deleteMasterItem(args.appId, args.dimensionId);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

// ===== MASTER MEASURE HANDLERS =====

export async function handleMasterMeasureCreate(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_measure_create called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.createMasterMeasure(args);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleMasterMeasureList(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_measure_list called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.listMasterMeasures(args.appId);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}

export async function handleMasterMeasureDelete(
  apiClient: ApiClient,
  cacheManager: CacheManager,
  args: any,
  platform: 'cloud' | 'on-premise' = 'cloud',
  tenantUrl: string = ''
): Promise<{ content: Array<{ type: string; text: string }> }> {
  console.error(`[VisualizationHandlers] master_measure_delete called (platform: ${platform})`);

  if (platform === 'on-premise') return cloudOnlyError;

  try {
    const service = new VisualizationService(apiClient, cacheManager, platform, tenantUrl);
    const result = await service.deleteMasterItem(args.appId, args.measureId);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify({ ...result, platform: 'cloud', timestamp: new Date().toISOString() }, null, 2)
      }]
    };
  } catch (error) {
    console.error('[VisualizationHandlers] Error:', error);
    return {
      content: [{
        type: 'text',
        text: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : String(error)
        }, null, 2)
      }]
    };
  }
}
