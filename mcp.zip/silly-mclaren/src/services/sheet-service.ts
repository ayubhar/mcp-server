/**
 * Sheet Service - Qlik Cloud Sheet Management
 *
 * Provides comprehensive sheet management operations using Engine API via enigma.js.
 * Handles CRUD operations for sheets in Qlik Sense apps.
 *
 * Cloud only - uses WebSocket connection to Qlik Engine API
 */

import { ApiClient } from '../utils/api-client.js';
import { CacheManager } from '../utils/cache-manager.js';
import { logger } from '../utils/logger.js';
import enigma from 'enigma.js';
import WebSocket from 'ws';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Load enigma schema
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let schema: any;
try {
  const schemaPath = join(__dirname, '../../node_modules/enigma.js/schemas/12.20.0.json');
  schema = JSON.parse(readFileSync(schemaPath, 'utf-8'));
} catch {
  try {
    const schemaPath = join(__dirname, '../../../node_modules/enigma.js/schemas/12.20.0.json');
    schema = JSON.parse(readFileSync(schemaPath, 'utf-8'));
  } catch (e) {
    console.error('[SheetService] Failed to load enigma schema:', e);
  }
}

export interface SheetCreateInput {
  appId: string;
  title: string;
  description?: string;
  columns?: number;
  rows?: number;
  rank?: number;
}

export interface SheetUpdateInput {
  appId: string;
  sheetId: string;
  title?: string;
  description?: string;
  columns?: number;
  rows?: number;
  rank?: number;
}

export interface SheetListInput {
  appId: string;
  includeObjects?: boolean;
}

export interface SheetGetInput {
  appId: string;
  sheetId: string;
  includeObjects?: boolean;
}

export interface SheetDeleteInput {
  appId: string;
  sheetId: string;
}

export interface SheetDuplicateInput {
  appId: string;
  sheetId: string;
  newTitle?: string;
}

export interface SheetObject {
  id: string;
  type: string;
  name?: string;
  bounds?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface SheetInfo {
  id: string;
  title: string;
  description?: string;
  rank?: number;
  columns?: number;
  rows?: number;
  approved?: boolean;
  published?: boolean;
  objects?: SheetObject[];
  totalObjects?: number;
}

export interface SheetResult {
  success: boolean;
  sheet?: SheetInfo;
  sheets?: SheetInfo[];
  message?: string;
  error?: string;
  sheetId?: string;
}

export class SheetService {
  private apiClient: ApiClient;
  private cacheManager: CacheManager;
  private platform: 'cloud' | 'on-premise';
  private tenantUrl: string;

  constructor(
    apiClient: ApiClient,
    cacheManager: CacheManager,
    platform: 'cloud' | 'on-premise' = 'cloud',
    tenantUrl: string = ''
  ) {
    this.apiClient = apiClient;
    this.cacheManager = cacheManager;
    this.platform = platform;
    this.tenantUrl = tenantUrl;
  }

  /**
   * Create a WebSocket session to the app using Engine API
   */
  private async createEngineSession(appId: string): Promise<any> {
    const url = new URL(this.tenantUrl);
    const wsUrl = `wss://${url.hostname}/app/${appId}`;

    const config: any = {
      schema,
      url: wsUrl,
      createSocket: (url: string) => {
        const headers: any = {};

        // Cloud: Use API key authentication
        const apiKey = process.env.QLIK_API_KEY;
        if (apiKey) {
          headers['Authorization'] = `Bearer ${apiKey}`;
        }

        return new WebSocket(url, {
          headers,
          rejectUnauthorized: false
        });
      }
    };

    return enigma.create(config);
  }

  /**
   * Create a new sheet in the app
   */
  async createSheet(input: SheetCreateInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Creating sheet in app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      // Create sheet object with properties
      const sheetProperties = {
        qInfo: {
          qType: 'sheet',
          qId: '' // Let Qlik generate the ID
        },
        qMetaDef: {
          title: input.title,
          description: input.description || ''
        },
        rank: input.rank ?? 0,
        columns: input.columns ?? 24,
        rows: input.rows ?? 12,
        cells: [] // Empty sheet initially
      };

      const sheetObject = await doc.createObject(sheetProperties);
      const layout = await sheetObject.getLayout();
      const sheetId = layout.qInfo.qId;

      // Save the app
      await doc.doSave();

      await session.close();

      return {
        success: true,
        sheetId,
        sheet: {
          id: sheetId,
          title: input.title,
          description: input.description,
          rank: input.rank,
          columns: input.columns ?? 24,
          rows: input.rows ?? 12,
          totalObjects: 0
        },
        message: `Sheet "${input.title}" created successfully with ID: ${sheetId}`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error creating sheet:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * List all sheets in the app
   */
  async listSheets(input: SheetListInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Listing sheets in app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      // Create a session object to list all sheets
      const sessionObjectDef = {
        qInfo: {
          qType: 'SheetsContainer',
          qId: ''
        },
        qAppObjectListDef: {
          qType: 'sheet',
          qData: {
            title: '/qMetaDef/title',
            description: '/qMetaDef/description',
            rank: '/rank',
            columns: '/columns',
            rows: '/rows',
            approved: '/approved',
            published: '/published'
          }
        }
      };

      const sessionObject = await doc.createSessionObject(sessionObjectDef);
      const layout = await sessionObject.getLayout();
      const sheetItems = layout.qAppObjectList?.qItems || [];

      const sheets: SheetInfo[] = [];

      for (const item of sheetItems) {
        const sheetInfo: SheetInfo = {
          id: item.qInfo.qId,
          title: item.qMeta?.title || item.qData?.title || 'Untitled Sheet',
          description: item.qMeta?.description || item.qData?.description || '',
          rank: item.qData?.rank,
          columns: item.qData?.columns,
          rows: item.qData?.rows,
          approved: item.qData?.approved,
          published: item.qData?.published
        };

        // Optionally get objects on the sheet
        if (input.includeObjects) {
          try {
            const sheetObject = await doc.getObject(item.qInfo.qId);
            const sheetLayout = await sheetObject.getLayout();

            if (sheetLayout.cells) {
              const objects: SheetObject[] = sheetLayout.cells
                .filter((cell: any) => cell.name && cell.type)
                .map((cell: any) => ({
                  id: cell.name,
                  type: cell.type,
                  bounds: cell.bounds ? {
                    x: cell.bounds.x || 0,
                    y: cell.bounds.y || 0,
                    width: cell.bounds.width || 1,
                    height: cell.bounds.height || 1
                  } : undefined
                }));

              sheetInfo.objects = objects;
              sheetInfo.totalObjects = objects.length;
            }
          } catch (e) {
            logger.warn(`[SheetService] Could not get objects for sheet ${item.qInfo.qId}:`, e as Error);
            sheetInfo.totalObjects = 0;
          }
        }

        sheets.push(sheetInfo);
      }

      await session.close();

      // Sort by rank
      sheets.sort((a, b) => (a.rank ?? 999) - (b.rank ?? 999));

      return {
        success: true,
        sheets,
        message: `Found ${sheets.length} sheets in app ${input.appId}`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error listing sheets:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Get detailed information about a specific sheet
   */
  async getSheet(input: SheetGetInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Getting sheet ${input.sheetId} from app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const sheetObject = await doc.getObject(input.sheetId);
      const layout = await sheetObject.getLayout();
      const properties = await sheetObject.getProperties();

      const sheetInfo: SheetInfo = {
        id: layout.qInfo.qId,
        title: layout.qMeta?.title || properties.qMetaDef?.title || 'Untitled Sheet',
        description: layout.qMeta?.description || properties.qMetaDef?.description || '',
        rank: properties.rank,
        columns: properties.columns,
        rows: properties.rows,
        approved: properties.approved,
        published: properties.published
      };

      // Get objects on the sheet if requested
      if (input.includeObjects && layout.cells) {
        const objects: SheetObject[] = layout.cells
          .filter((cell: any) => cell.name && cell.type)
          .map((cell: any) => ({
            id: cell.name,
            type: cell.type,
            name: cell.label,
            bounds: cell.bounds ? {
              x: cell.bounds.x || 0,
              y: cell.bounds.y || 0,
              width: cell.bounds.width || 1,
              height: cell.bounds.height || 1
            } : undefined
          }));

        sheetInfo.objects = objects;
        sheetInfo.totalObjects = objects.length;
      }

      await session.close();

      return {
        success: true,
        sheet: sheetInfo,
        message: `Retrieved sheet "${sheetInfo.title}"`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error getting sheet:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Update sheet properties
   */
  async updateSheet(input: SheetUpdateInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Updating sheet ${input.sheetId} in app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const sheetObject = await doc.getObject(input.sheetId);
      const properties = await sheetObject.getProperties();

      // Update only provided properties
      if (input.title !== undefined) {
        properties.qMetaDef = properties.qMetaDef || {};
        properties.qMetaDef.title = input.title;
      }
      if (input.description !== undefined) {
        properties.qMetaDef = properties.qMetaDef || {};
        properties.qMetaDef.description = input.description;
      }
      if (input.rank !== undefined) {
        properties.rank = input.rank;
      }
      if (input.columns !== undefined) {
        properties.columns = input.columns;
      }
      if (input.rows !== undefined) {
        properties.rows = input.rows;
      }

      // Apply updated properties
      await sheetObject.setProperties(properties);
      await doc.doSave();

      const updatedLayout = await sheetObject.getLayout();
      const updatedProperties = await sheetObject.getProperties();

      await session.close();

      return {
        success: true,
        sheet: {
          id: input.sheetId,
          title: updatedLayout.qMeta?.title || updatedProperties.qMetaDef?.title,
          description: updatedLayout.qMeta?.description || updatedProperties.qMetaDef?.description,
          rank: updatedProperties.rank,
          columns: updatedProperties.columns,
          rows: updatedProperties.rows
        },
        message: `Sheet updated successfully`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error updating sheet:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Delete a sheet from the app
   */
  async deleteSheet(input: SheetDeleteInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Deleting sheet ${input.sheetId} from app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      // Get sheet info before deleting
      const sheetObject = await doc.getObject(input.sheetId);
      const layout = await sheetObject.getLayout();
      const sheetTitle = layout.qMeta?.title || 'Untitled Sheet';

      // Destroy the sheet object
      await doc.destroyObject(input.sheetId);
      await doc.doSave();

      await session.close();

      return {
        success: true,
        message: `Sheet "${sheetTitle}" (${input.sheetId}) deleted successfully`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error deleting sheet:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Duplicate a sheet (create a copy with all objects)
   */
  async duplicateSheet(input: SheetDuplicateInput): Promise<SheetResult> {
    logger.debug(`[SheetService] Duplicating sheet ${input.sheetId} in app ${input.appId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      // Get original sheet properties
      const originalSheet = await doc.getObject(input.sheetId);
      const originalProperties = await originalSheet.getProperties();
      const originalLayout = await originalSheet.getLayout();

      // Create new properties for the duplicated sheet
      const newProperties = JSON.parse(JSON.stringify(originalProperties));
      newProperties.qInfo.qId = ''; // Let Qlik generate new ID

      // Update title
      const originalTitle = originalLayout.qMeta?.title || originalProperties.qMetaDef?.title || 'Untitled Sheet';
      const newTitle = input.newTitle || `Copy of ${originalTitle}`;
      newProperties.qMetaDef = newProperties.qMetaDef || {};
      newProperties.qMetaDef.title = newTitle;

      // Create the new sheet
      const newSheet = await doc.createObject(newProperties);
      const newLayout = await newSheet.getLayout();
      const newSheetId = newLayout.qInfo.qId;

      await doc.doSave();
      await session.close();

      return {
        success: true,
        sheetId: newSheetId,
        sheet: {
          id: newSheetId,
          title: newTitle,
          description: newProperties.qMetaDef?.description,
          rank: newProperties.rank,
          columns: newProperties.columns,
          rows: newProperties.rows
        },
        message: `Sheet duplicated successfully. New sheet ID: ${newSheetId}`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[SheetService] Error duplicating sheet:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
}
