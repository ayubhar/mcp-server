/**
 * Visualization Service - Qlik Cloud Visualization, Field, and Master Items Management
 *
 * Comprehensive service for:
 * 1. Creating and managing visualizations (straight tables/sn-table)
 * 2. Field operations (list, get values, get metadata)
 * 3. Master items (dimensions and measures)
 *
 * Uses Engine API via enigma.js
 * Cloud only
 */

import { ApiClient } from '../utils/api-client.js';
import { CacheManager } from '../utils/cache-manager.js';
import { logger } from '../utils/logger.js';
import enigma from 'enigma.js';
import WebSocket from 'ws';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Load enigma schema
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let schema: any;
try {
  const schemaPath = join(__dirname, '../../node_modules/enigma.js/schemas/12.20.0.json');
  schema = JSON.parse(readFileSync(schemaPath, 'utf-8'));
} catch {
  try {
    const schemaPath = join(__dirname, '../../../node_modules/enigma.js/schemas/12.20.0.json');
    schema = JSON.parse(readFileSync(schemaPath, 'utf-8'));
  } catch (e) {
    console.error('[VisualizationService] Failed to load enigma schema:', e);
  }
}

// ===== INTERFACES =====

export interface ColumnProperties {
  /** Column label displayed in header */
  label?: string;
  /** Show column if expression (condition to show/hide column) */
  showColumnIf?: string;
  /** Background color expression (e.g., "if(Sum(Price) > 30000, '#ff6b6b', '#51cf66')") */
  backgroundColorExpression?: string;
  /** Text/foreground color expression */
  textColorExpression?: string;
  /** Text alignment - auto or specific alignment */
  textAlign?: {
    auto?: boolean;
    align?: 'left' | 'center' | 'right';
  };
  /** Column width configuration */
  columnWidth?: {
    type?: 'auto' | 'fitToContent' | 'pixels' | 'percentage';
    pixels?: string;
    percentage?: string;
  };
}

export interface DimensionDef {
  field: string;
  label?: string;
  /** Column-specific properties for tables */
  columnProps?: ColumnProperties;
}

export interface MeasureDef {
  expression: string;
  label?: string;
  /** Column-specific properties for tables */
  columnProps?: ColumnProperties;
}

export interface VisualizationPosition {
  x?: number;
  y?: number;
  width?: number;
  height?: number;
}

export interface TableProperties {
  totals?: {
    show?: boolean;
    position?: 'top' | 'bottom';
    label?: string;
  };
  styling?: {
    header?: {
      fontSize?: string;
      fontColor?: { color?: string };
      backgroundColor?: { color?: string };
    };
    rows?: {
      fontSize?: string;
      padding?: string;
    };
  };
}

export interface PieChartProperties {
  appearance?: {
    style?: 'pie' | 'donut';
    dimensionLabels?: boolean;
    valueLabels?: boolean;
    legend?: {
      show?: boolean;
      position?: 'right' | 'left' | 'top' | 'bottom';
    };
    colors?: {
      auto?: boolean;
      customColors?: string[];
    };
  };
  filters?: Array<{
    field: string;
    values: string[];
  }>;
}

export interface KPIProperties {
  appearance?: {
    textAlign?: 'left' | 'center' | 'right';
    fontSize?: 'S' | 'M' | 'L';
    showMeasureTitle?: boolean;
    backgroundColor?: string;
    backgroundExpression?: string;
    conditionalColor?: {
      useConditionalColor?: boolean;
      conditions?: Array<{
        condition: string;
        color: string;
      }>;
    };
  };
  navigation?: {
    useLink?: boolean;
    sheetLink?: string;
    openInNewTab?: boolean;
  };
}

export interface BarChartProperties {
  appearance?: {
    orientation?: 'vertical' | 'horizontal';
    barGrouping?: 'grouped' | 'stacked';
    colors?: {
      auto?: boolean;
      mode?: 'primary' | 'byDimension' | 'byExpression' | 'byMeasure';
      customColors?: string[];
    };
    legend?: {
      show?: boolean;
      position?: 'auto' | 'right' | 'left' | 'top' | 'bottom';
    };
  };
  dataLabels?: {
    show?: boolean;
    showSegmentLabels?: boolean;
    showTotalLabels?: boolean;
  };
  axes?: {
    dimensionAxis?: {
      show?: 'all' | 'labels' | 'title' | 'none';
      label?: 'auto' | 'horizontal' | 'tilted';
    };
    measureAxis?: {
      show?: 'all' | 'labels' | 'title' | 'none';
      autoMinMax?: boolean;
      min?: number;
      max?: number;
    };
  };
  gridLines?: {
    auto?: boolean;
    spacing?: number;
  };
}

export interface FilterPaneProperties {
  dimensions: Array<{
    field: string;
    label?: string;
    collapse?: 'auto' | 'always' | 'never';
    layoutMode?: 'singleColumn' | 'grid';
    showSearch?: boolean;
  }>;
  appearance?: {
    collapseBehavior?: 'auto' | 'always' | 'never';
  };
}

export interface VisualizationCreateInput {
  appId: string;
  sheetId: string;
  title: string;
  visualizationType?: string;
  dimensions: DimensionDef[];
  measures: MeasureDef[];
  position?: VisualizationPosition;
  tableProperties?: TableProperties;
  pieChartProperties?: PieChartProperties;
  kpiProperties?: KPIProperties;
  barChartProperties?: BarChartProperties;
  filterPaneProperties?: FilterPaneProperties;
}

export interface VisualizationResult {
  success: boolean;
  visualization?: any;
  visualizations?: any[];
  error?: string;
  message?: string;
}

export interface FieldListInput {
  appId: string;
  includeSystem?: boolean;
  includeTags?: boolean;
}

export interface FieldValuesInput {
  appId: string;
  fieldName: string;
  limit?: number;
  searchTerm?: string;
}

export interface FieldInfoInput {
  appId: string;
  fieldName: string;
  includeSample?: boolean;
}

export interface MasterDimensionInput {
  appId: string;
  field: string;
  label: string;
  description?: string;
  tags?: string[];
}

export interface MasterMeasureInput {
  appId: string;
  expression: string;
  label: string;
  description?: string;
  tags?: string[];
  numberFormat?: any;
}

export class VisualizationService {
  private apiClient: ApiClient;
  private cacheManager: CacheManager;
  private platform: 'cloud' | 'on-premise';
  private tenantUrl: string;

  constructor(
    apiClient: ApiClient,
    cacheManager: CacheManager,
    platform: 'cloud' | 'on-premise' = 'cloud',
    tenantUrl: string = ''
  ) {
    this.apiClient = apiClient;
    this.cacheManager = cacheManager;
    this.platform = platform;
    this.tenantUrl = tenantUrl;
  }

  /**
   * Create Engine API session for an app
   */
  private async createEngineSession(appId: string): Promise<any> {
    const url = new URL(this.tenantUrl);
    const wsUrl = `wss://${url.hostname}/app/${appId}`;

    const config: any = {
      schema,
      url: wsUrl,
      createSocket: (url: string) => {
        const headers: any = {};
        const apiKey = process.env.QLIK_API_KEY;
        if (apiKey) {
          headers['Authorization'] = `Bearer ${apiKey}`;
        }
        return new WebSocket(url, { headers, rejectUnauthorized: false });
      }
    };

    return enigma.create(config);
  }

  // ===== VISUALIZATION OPERATIONS =====

  /**
   * Create a straight table visualization on a sheet
   */
  async createVisualization(input: VisualizationCreateInput): Promise<VisualizationResult> {
    logger.debug(`[VisualizationService] Creating visualization in app ${input.appId}, sheet ${input.sheetId}`);

    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      // Get sheet object
      const sheet = await doc.getObject(input.sheetId);
      const sheetProps = await sheet.getProperties();

      // Build base hypercube definition
      // FIXED: Using exact structure from Qlik Cloud HAR capture
      const totalColumns = input.dimensions.length + input.measures.length;

      // Generate unique IDs for dimensions and measures
      const generateId = () => Math.random().toString(36).substring(2, 8);

      const qHyperCubeDef: any = {
        qStateName: '',
        qDimensions: input.dimensions.map((dim, index) => ({
          qLibraryId: '',
          qDef: {
            qGrouping: 'N',
            qFieldDefs: [dim.field],
            qFieldLabels: [dim.label || ''],
            qSortCriterias: [{
              qSortByState: 0,
              qSortByFrequency: 0,
              qSortByNumeric: 1,
              qSortByAscii: 1,
              qSortByLoadOrder: 1,
              qSortByExpression: 0,
              qExpression: { qv: '' },
              qSortByGreyness: 0
            }],
            qNumberPresentations: [],
            qReverseSort: false,
            qActiveField: 0,
            qLabelExpression: '',
            autoSort: true,
            cId: generateId(),
            othersLabel: 'Others'
          },
          qNullSuppression: false,
          qIncludeElemValue: false,
          qOtherTotalSpec: {
            qOtherMode: 'OTHER_OFF',
            qOtherCounted: { qv: '10' },
            qOtherLimit: { qv: '0' },
            qOtherLimitMode: 'OTHER_GE_LIMIT',
            qSuppressOther: false,
            qForceBadValueKeeping: true,
            qApplyEvenWhenPossiblyWrongResult: true,
            qGlobalOtherGrouping: false,
            qOtherCollapseInnerDimensions: false,
            qOtherSortMode: 'OTHER_SORT_DESCENDING',
            qTotalMode: 'TOTAL_OFF',
            qReferencedExpression: { qv: '' }
          },
          qShowTotal: false,
          qShowAll: false,
          qOtherLabel: { qv: 'Others' },
          qTotalLabel: { qv: '' },
          qCalcCond: { qv: '' },
          qAttributeExpressions: [],
          qAttributeDimensions: [],
          qCalcCondition: { qCond: { qv: '' }, qMsg: { qv: '' } }
        })),
        qMeasures: input.measures.map((measure, index) => ({
          qLibraryId: '',
          qDef: {
            qDef: measure.expression,
            qLabel: measure.label || measure.expression,
            autoSort: true,
            cId: generateId(),
            numFormatFromTemplate: true,
            qNumFormat: {}
          },
          qSortBy: {
            qSortByLoadOrder: 1,
            qSortByNumeric: -1
          },
          qCalcCondition: { qCond: { qv: '' } },
          qTrendLines: []
        })),
        qInterColumnSortOrder: [...Array(totalColumns).keys()],
        qSuppressZero: false,
        qSuppressMissing: true,
        qInitialDataFetch: [{
          qLeft: 0,
          qTop: 0,
          qWidth: 17,
          qHeight: 500
        }],
        qReductionMode: 'N',
        qMode: 'S',
        qPseudoDimPos: -1,
        qNoOfLeftDims: -1,
        qAlwaysFullyExpanded: false,
        qMaxStackedCells: 5000,
        qPopulateMissing: false,
        qShowTotalsAbove: false,
        qIndentMode: false,
        qCalcCond: { qv: '' },
        qSortbyYValue: 0,
        qTitle: { qv: '' },
        qCalcCondition: { qCond: { qv: '' }, qMsg: { qv: '' } },
        qColumnOrder: [],
        qExpansionState: [],
        qDynamicScript: [],
        qContextSetExpression: '',
        qSuppressMeasureTotals: false
      };

      // Add filters if provided (works for both table and pie chart)
      if (input.pieChartProperties?.filters && input.pieChartProperties.filters.length > 0) {
        qHyperCubeDef.qCalcCondition = {
          qCond: {
            qv: input.pieChartProperties.filters.map(f =>
              `GetSelectedCount([${f.field}]) = 0 or Match([${f.field}], ${f.values.map(v => `'${v}'`).join(', ')})`
            ).join(' and ')
          }
        };
      }

      const vizType = input.visualizationType || 'sn-table';
      const vizSpecificProps: any = {};

      // Build visualization-specific properties
      if (vizType === 'piechart') {
        // Pie chart specific properties
        const pieProps = input.pieChartProperties?.appearance;

        // Color configuration
        vizSpecificProps.color = {
          auto: pieProps?.colors?.auto ?? true
        };

        if (pieProps?.colors?.customColors && pieProps.colors.customColors.length > 0) {
          vizSpecificProps.color.auto = false;
          vizSpecificProps.color.mode = 'primary';
          vizSpecificProps.color.paletteColor = {
            index: -1,
            color: pieProps.colors.customColors[0]
          };
        }

        // Donut vs Pie style
        vizSpecificProps.donut = {
          showAsDonut: pieProps?.style === 'donut'
        };

        // Data point labels (dimension and value labels)
        const showDimensionLabels = pieProps?.dimensionLabels ?? true;
        const showValueLabels = pieProps?.valueLabels ?? true;

        if (showDimensionLabels && showValueLabels) {
          vizSpecificProps.dataPoint = {
            auto: false,
            labelMode: 'share'  // Shows both dimension and percentage
          };
        } else if (showValueLabels) {
          vizSpecificProps.dataPoint = {
            auto: false,
            labelMode: 'value'  // Shows only values
          };
        } else {
          vizSpecificProps.dataPoint = {
            auto: false,
            labelMode: 'none'   // No labels
          };
        }

        // Legend configuration
        vizSpecificProps.legend = {
          show: pieProps?.legend?.show ?? true,
          dock: pieProps?.legend?.position || 'right',
          showTitle: true
        };

      } else if (vizType === 'sn-table' || vizType === 'straight-table') {
        // sn-table (straight table) specific properties - FIXED: Using exact structure from HAR

        // Update qHyperCubeDef for sn-table specific settings
        qHyperCubeDef.qInitialDataFetch = [{
          qLeft: 0,
          qTop: 0,
          qWidth: 50,
          qHeight: 100
        }];

        // Add column order
        qHyperCubeDef.qColumnOrder = [...Array(totalColumns).keys()];

        // Add dimension-specific properties for sn-table
        qHyperCubeDef.qDimensions = input.dimensions.map((dim, index) => {
          const colProps = dim.columnProps || {};

          // Build qAttributeExpressions for color expressions
          const qAttributeExpressions: any[] = [];
          if (colProps.backgroundColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.backgroundColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellBackgroundColor'
            });
          }
          if (colProps.textColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.textColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellForegroundColor'
            });
          }

          // Build textAlign from columnProps or use defaults
          const textAlign = colProps.textAlign || { auto: true, align: 'left' };

          // Build columnWidth from columnProps or use defaults
          const columnWidth = colProps.columnWidth || { type: 'auto', pixels: '200', percentage: '20' };

          return {
            qLibraryId: '',
            qNullSuppression: false,
            qOtherTotalSpec: {
              qOtherMode: 'OTHER_OFF',
              qOtherSortMode: 'OTHER_SORT_DESCENDING',
              qOtherCounted: { qv: '10' },
              qOtherLimitMode: 'OTHER_GE_LIMIT',
              qOtherLimit: { qv: '0' },
              qSuppressOther: false
            },
            qDef: {
              othersLabel: 'Others',
              autoSort: true,
              textAlign: textAlign,
              columnWidth: columnWidth,
              representation: {
                type: 'text',
                urlPosition: 'dimension',
                urlLabel: '',
                linkUrl: '',
                imageSetting: 'label',
                imageLabel: '',
                imageUrl: '',
                imageSize: 'fitHeight',
                imagePosition: 'topCenter',
                imageBox: { width: 24 }
              },
              qFieldDefs: [dim.field],
              qFieldLabels: [colProps.label || dim.label || ''],
              qSortCriterias: [{
                qSortByLoadOrder: 1,
                qSortByNumeric: 1,
                qSortByAscii: 1
              }],
              cId: generateId()
            },
            qOtherLabel: 'Others',
            qCalcCondition: {
              qCond: { qv: colProps.showColumnIf || '' },
              qMsg: { qv: '' }
            },
            qAttributeExpressions: qAttributeExpressions
          };
        });

        // Add measure-specific properties for sn-table
        qHyperCubeDef.qMeasures = input.measures.map((measure, index) => {
          const colProps = measure.columnProps || {};

          // Build qAttributeExpressions for color expressions
          const qAttributeExpressions: any[] = [];
          if (colProps.backgroundColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.backgroundColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellBackgroundColor'
            });
          }
          if (colProps.textColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.textColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellForegroundColor'
            });
          }

          // Build textAlign from columnProps or use defaults
          const textAlign = colProps.textAlign || { auto: true, align: 'left' };

          // Build columnWidth from columnProps or use defaults
          const columnWidth = colProps.columnWidth || { type: 'auto', pixels: '200', percentage: '20' };

          return {
            qLibraryId: '',
            qDef: {
              numFormatFromTemplate: true,
              qAggrFunc: 'Expr',
              autoSort: true,
              textAlign: textAlign,
              columnWidth: columnWidth,
              representation: {
                type: 'text',
                imageSetting: 'label',
                imageLabel: '',
                imageUrl: '',
                imageSize: 'fitHeight',
                imagePosition: 'topCenter',
                indicator: {
                  showTextValues: true,
                  applySegmentColors: false,
                  position: 'right'
                },
                miniChart: {
                  type: 'sparkline',
                  colors: {
                    main: { index: 6 },
                    max: { index: 0, color: 'none' },
                    min: { index: 0, color: 'none' },
                    first: { index: 0, color: 'none' },
                    last: { index: 0, color: 'none' },
                    positive: { index: 6 },
                    negative: { index: 10, color: '#f93f17' }
                  },
                  showDots: true,
                  yAxis: { scale: 'local', position: 'auto' }
                }
              },
              conditionalColoring: {
                segments: {
                  limits: [],
                  paletteColors: [{ index: 6, icon: 'dot' }]
                }
              },
              qNumFormat: {},
              qDef: measure.expression,
              qLabel: colProps.label || measure.label || '',
              cId: generateId()
            },
            qCalcCondition: {
              qCond: { qv: colProps.showColumnIf || '' },
              qMsg: { qv: '' }
            },
            qAttributeExpressions: qAttributeExpressions,
            qMiniChartDef: {
              qNullSuppression: true,
              qOtherTotalSpec: { qSuppressOther: true }
            },
            qSortBy: {
              qSortByLoadOrder: 1,
              qSortByNumeric: -1
            }
          };
        });

        // Add qLayoutExclude
        qHyperCubeDef.qLayoutExclude = {
          qHyperCubeDef: {
            qDimensions: [],
            qMeasures: []
          }
        };

        // sn-table visualization properties
        vizSpecificProps.columns = null;
        vizSpecificProps.filter = null;
        vizSpecificProps.components = [];
        vizSpecificProps.totals = {
          show: input.tableProperties?.totals?.show ?? true,
          position: input.tableProperties?.totals?.position || 'noTotals',
          label: input.tableProperties?.totals?.label || 'Totals'
        };
        vizSpecificProps.usePagination = false;
        vizSpecificProps.accessibleHeader = false;
        vizSpecificProps.multiline = {
          wrapTextInHeaders: true,
          wrapTextInCells: true
        };
        vizSpecificProps.hideHeader = false;
        vizSpecificProps.nullValueRepresentation = { text: '-' };
        vizSpecificProps.enableChartExploration = false;
        vizSpecificProps.chartExploration = { menuVisibility: 'auto' };
        vizSpecificProps.visualization = 'sn-table';
        vizSpecificProps.version = '"6.4.0"';

      } else if (vizType === 'pivot-table') {
        // Pivot table specific properties - FIXED: Using exact structure from HAR

        // Update qHyperCubeDef for pivot table
        qHyperCubeDef.qMode = 'P';  // Pivot mode
        qHyperCubeDef.qNoOfLeftDims = input.dimensions.length;  // All dimensions on left by default
        qHyperCubeDef.qShowTotalsAbove = true;
        qHyperCubeDef.qIndentMode = true;
        qHyperCubeDef.qSuppressMissing = true;
        qHyperCubeDef.qInitialDataFetch = [{
          qLeft: 0,
          qTop: 0,
          qWidth: 50,
          qHeight: 50
        }];
        qHyperCubeDef.columnWidths = [];

        // Add dimension-specific properties for pivot table
        qHyperCubeDef.qDimensions = input.dimensions.map((dim, index) => ({
          qLibraryId: '',
          qDef: {
            autoSort: true,
            cId: generateId(),
            othersLabel: 'Others',
            textAlign: { auto: true, align: 'left' },
            qFieldDefs: [dim.field],
            qFieldLabels: [dim.label || ''],
            qSortCriterias: [{
              qSortByLoadOrder: 1,
              qSortByNumeric: 1,
              qSortByAscii: 1
            }]
          },
          qNullSuppression: false,
          qOtherTotalSpec: {
            qOtherMode: 'OTHER_OFF',
            qOtherSortMode: 'OTHER_SORT_DESCENDING',
            qOtherCounted: { qv: '10' },
            qOtherLimitMode: 'OTHER_GE_LIMIT',
            qOtherLimit: { qv: '0' },
            qSuppressOther: false,
            qGlobalOtherGrouping: false,
            qTotalMode: 'TOTAL_OFF'
          },
          qOtherLabel: 'Others',
          qTotalLabel: 'Totals',
          qCalcCondition: { qCond: { qv: '' } },
          qAttributeExpressions: [
            { qExpression: '', qAttribute: true },
            { qExpression: '', qAttribute: true }
          ]
        }));

        // Add measure-specific properties for pivot table
        qHyperCubeDef.qMeasures = input.measures.map((measure, index) => ({
          qLibraryId: '',
          qDef: {
            autoSort: true,
            cId: generateId(),
            numFormatFromTemplate: true,
            textAlign: { auto: true, align: 'left' },
            qDef: measure.expression
          },
          qCalcCondition: { qCond: { qv: '' } },
          qAttributeExpressions: [
            { qExpression: '', qAttribute: true },
            { qExpression: '', qAttribute: true }
          ],
          qSortBy: {
            qSortByLoadOrder: 1,
            qSortByNumeric: -1
          }
        }));

        // Add rankedList for pivot table
        const dimIds = qHyperCubeDef.qDimensions.map((d: any) => d.qDef.cId);
        const measureIds = qHyperCubeDef.qMeasures.map((m: any) => m.qDef.cId);
        qHyperCubeDef.rankedList = {
          rows: dimIds,
          measures: measureIds
        };

        // Add qLayoutExclude
        qHyperCubeDef.qLayoutExclude = {
          qHyperCubeDef: {
            qDimensions: [],
            qMeasures: []
          }
        };

        // Pivot table visualization properties
        vizSpecificProps.filter = null;
        vizSpecificProps.search = { sorting: 'auto' };
        vizSpecificProps.visualization = 'pivot-table';

      } else if (vizType === 'table') {
        // Legacy table specific properties - FIXED: Using exact structure from HAR

        // Update qHyperCubeDef for legacy table
        qHyperCubeDef.qInitialDataFetch = [];  // Empty for legacy table
        qHyperCubeDef.qColumnOrder = [...Array(totalColumns).keys()];
        qHyperCubeDef.columnOrder = [...Array(totalColumns).keys()];
        qHyperCubeDef.columnWidths = Array(totalColumns).fill(-1);

        // Add dimension-specific properties for legacy table
        qHyperCubeDef.qDimensions = input.dimensions.map((dim, index) => {
          const colProps = dim.columnProps || {};

          // Build qAttributeExpressions for color expressions
          const qAttributeExpressions: any[] = [];
          if (colProps.backgroundColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.backgroundColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellBackgroundColor'
            });
          }
          if (colProps.textColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.textColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellForegroundColor'
            });
          }

          // Build textAlign from columnProps or use defaults
          const textAlign = colProps.textAlign || { auto: true, align: 'left' };

          return {
            qLibraryId: '',
            qDef: {
              qGrouping: 'N',
              qFieldDefs: [dim.field],
              qFieldLabels: [colProps.label || dim.label || ''],
              qSortCriterias: [{
                qSortByState: 0,
                qSortByFrequency: 0,
                qSortByNumeric: 1,
                qSortByAscii: 1,
                qSortByLoadOrder: 1,
                qSortByExpression: 0,
                qExpression: { qv: '' },
                qSortByGreyness: 0
              }],
              qNumberPresentations: [],
              qReverseSort: false,
              qActiveField: 0,
              qLabelExpression: '',
              qAlias: '',
              autoSort: true,
              cId: generateId(),
              othersLabel: 'Others',
              textAlign: textAlign,
              representation: {
                type: 'text',
                urlPosition: 'dimension',
                urlLabel: '',
                linkUrl: '',
                imageSetting: 'label',
                imageLabel: '',
                imageUrl: '',
                imageSize: 'fitHeight',
                imagePosition: 'topCenter'
              }
            },
            qNullSuppression: false,
            qIncludeElemValue: false,
            qOtherTotalSpec: {
              qOtherMode: 'OTHER_OFF',
              qOtherCounted: { qv: '10' },
              qOtherLimit: { qv: '0' },
              qOtherLimitMode: 'OTHER_GE_LIMIT',
              qSuppressOther: false,
              qForceBadValueKeeping: true,
              qApplyEvenWhenPossiblyWrongResult: true,
              qGlobalOtherGrouping: false,
              qOtherCollapseInnerDimensions: false,
              qOtherSortMode: 'OTHER_SORT_DESCENDING',
              qTotalMode: 'TOTAL_OFF',
              qReferencedExpression: { qv: '' }
            },
            qShowTotal: false,
            qShowAll: false,
            qOtherLabel: { qv: 'Others' },
            qTotalLabel: { qv: '' },
            qCalcCond: { qv: '' },
            qAttributeExpressions: qAttributeExpressions,
            qAttributeDimensions: [],
            qCalcCondition: {
              qCond: { qv: colProps.showColumnIf || '' },
              qMsg: { qv: '' }
            }
          };
        });

        // Add measure-specific properties for legacy table
        qHyperCubeDef.qMeasures = input.measures.map((measure, index) => {
          const colProps = measure.columnProps || {};

          // Build qAttributeExpressions for color expressions
          const qAttributeExpressions: any[] = [];
          if (colProps.backgroundColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.backgroundColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellBackgroundColor'
            });
          }
          if (colProps.textColorExpression) {
            qAttributeExpressions.push({
              qExpression: colProps.textColorExpression,
              qLibraryId: '',
              qAttribute: true,
              qNumFormat: null,
              qLabel: '',
              qLabelExpression: '',
              id: 'cellForegroundColor'
            });
          }

          // Build textAlign from columnProps or use defaults
          const textAlign = colProps.textAlign || { auto: true, align: 'left' };

          return {
            qLibraryId: '',
            qDef: {
              autoSort: true,
              cId: generateId(),
              numFormatFromTemplate: true,
              textAlign: textAlign,
              qAggrFunc: 'Expr',
              representation: {
                type: 'text',
                indicator: {
                  showTextValues: true,
                  applySegmentColors: false,
                  position: 'right'
                },
                miniChart: {
                  type: 'sparkline',
                  colors: {
                    main: { index: 6 },
                    max: { index: 0, color: 'none' },
                    min: { index: 0, color: 'none' },
                    first: { index: 0, color: 'none' },
                    last: { index: 0, color: 'none' },
                    positive: { index: 6 },
                    negative: { index: 10, color: '#f93f17' }
                  },
                  showDots: true,
                  yAxis: { scale: 'local', position: 'auto' }
                },
                imageSetting: 'label',
                imageLabel: '',
                imageUrl: '',
                imageSize: 'fitHeight',
                imagePosition: 'topCenter'
              },
              conditionalColoring: {
                segments: {
                  limits: [],
                  paletteColors: [{ index: 6, icon: 'dot' }]
                }
              },
              qNumFormat: {},
              qDef: measure.expression,
              qLabel: colProps.label || measure.label || ''
            },
            qCalcCondition: {
              qCond: { qv: colProps.showColumnIf || '' },
              qMsg: { qv: '' }
            },
            qAttributeExpressions: qAttributeExpressions,
            qMiniChartDef: {
              qNullSuppression: true,
              qOtherTotalSpec: { qSuppressOther: true }
            },
            qSortBy: {
              qSortByLoadOrder: 1,
              qSortByNumeric: -1
            }
          };
        });

        // Add qLayoutExclude
        qHyperCubeDef.qLayoutExclude = {
          qHyperCubeDef: {
            qDimensions: [],
            qMeasures: []
          }
        };

        // Legacy table visualization properties
        vizSpecificProps.script = '';
        vizSpecificProps.filter = null;
        vizSpecificProps.search = { sorting: 'auto' };
        vizSpecificProps.totals = {
          show: input.tableProperties?.totals?.show ?? true,
          position: input.tableProperties?.totals?.position || 'noTotals',
          label: input.tableProperties?.totals?.label || 'Totals'
        };
        vizSpecificProps.scrolling = {
          horizontal: true,
          keepFirstColumnInView: false,
          keepFirstColumnInViewTouch: false
        };
        vizSpecificProps.multiline = {
          wrapTextInHeaders: true,
          wrapTextInCells: true
        };
        vizSpecificProps.visualization = 'table';

      } else if (vizType === 'kpi') {
        // KPI specific properties
        const kpiProps = input.kpiProperties?.appearance;

        // Text alignment
        vizSpecificProps.textAlign = kpiProps?.textAlign || 'center';

        // Font size
        vizSpecificProps.fontSize = kpiProps?.fontSize || 'M';

        // Show measure title
        vizSpecificProps.showMeasureTitle = kpiProps?.showMeasureTitle ?? true;

        // Background color
        if (kpiProps?.backgroundColor) {
          vizSpecificProps.style = {
            backgroundColor: kpiProps.backgroundColor
          };
        } else if (kpiProps?.backgroundExpression) {
          vizSpecificProps.style = {
            backgroundExpression: kpiProps.backgroundExpression
          };
        }

        // Conditional coloring
        if (kpiProps?.conditionalColor?.useConditionalColor && kpiProps.conditionalColor.conditions) {
          vizSpecificProps.conditionalColor = {
            useConditionalColor: true,
            conditions: kpiProps.conditionalColor.conditions.map(c => ({
              condition: c.condition,
              color: c.color
            }))
          };
        }

        // Navigation/linking
        if (input.kpiProperties?.navigation) {
          const nav = input.kpiProperties.navigation;
          vizSpecificProps.useLink = nav.useLink ?? false;
          if (nav.sheetLink) {
            vizSpecificProps.sheetLink = nav.sheetLink;
          }
          vizSpecificProps.openUrlInNewTab = nav.openInNewTab ?? true;
        }

      } else if (vizType === 'barchart') {
        // Bar chart specific properties - FIXED: Using exact structure from Qlik Cloud HAR capture
        const barProps = input.barChartProperties?.appearance;
        const groupingMode = barProps?.barGrouping || 'grouped';

        // If stacked, set qHyperCubeDef mode
        if (groupingMode === 'stacked') {
          qHyperCubeDef.qMode = 'K';  // K mode for stacked
        }

        // Bar grouping - nested object structure as per HAR
        vizSpecificProps.barGrouping = {
          grouping: groupingMode
        };

        // Orientation
        vizSpecificProps.orientation = barProps?.orientation || 'vertical';

        // Scrollbar
        vizSpecificProps.scrollbar = 'miniChart';
        vizSpecificProps.scrollStartPos = 0;

        // Grid lines
        vizSpecificProps.gridLine = {
          auto: true,
          spacing: 2
        };

        // Data labels
        vizSpecificProps.dataPoint = {
          showLabels: input.barChartProperties?.dataLabels?.show ?? false,
          showSegmentLabels: false,
          showTotalLabels: true
        };

        // Color configuration - full structure from HAR
        vizSpecificProps.color = {
          auto: barProps?.colors?.auto ?? true,
          mode: barProps?.colors?.mode || 'primary',
          formatting: {
            numFormatFromTemplate: true
          },
          useBaseColors: 'off',
          paletteColor: {
            index: 6
          },
          useDimColVal: true,
          useMeasureGradient: true,
          persistent: false,
          expressionIsColor: true,
          expressionLabel: '',
          measureScheme: 'sg',
          reverseScheme: false,
          dimensionScheme: '12',
          autoMinMax: true,
          measureMin: 0,
          measureMax: 10
        };

        // Legend
        vizSpecificProps.legend = {
          show: barProps?.legend?.show ?? true,
          dock: barProps?.legend?.position || 'auto',
          showTitle: true
        };

        // Dimension axis - full structure from HAR
        vizSpecificProps.dimensionAxis = {
          continuousAuto: true,
          show: input.barChartProperties?.axes?.dimensionAxis?.show || 'all',
          label: 'auto',
          dock: 'near',
          axisDisplayMode: 'auto',
          maxVisibleItems: 10
        };

        // Prefer continuous axis
        vizSpecificProps.preferContinuousAxis = true;

        // Measure axis - full structure from HAR
        vizSpecificProps.measureAxis = {
          show: input.barChartProperties?.axes?.measureAxis?.show || 'all',
          dock: 'near',
          spacing: 1,
          autoMinMax: input.barChartProperties?.axes?.measureAxis?.autoMinMax ?? true,
          minMax: 'min',
          min: 0,
          max: 10
        };

        // Tooltip
        vizSpecificProps.tooltip = {
          auto: true,
          hideBasic: false,
          chart: {
            style: {
              size: 'medium'
            }
          },
          data: {}
        };

        // Reference lines
        vizSpecificProps.refLine = {
          refLines: [],
          dimRefLines: []
        };

        // Other required properties from HAR
        vizSpecificProps.script = '';
        vizSpecificProps.filter = null;
        vizSpecificProps.plugins = [];
        vizSpecificProps.disableNavMenu = false;
        vizSpecificProps.showDetails = true;
        vizSpecificProps.showDetailsExpression = false;
        vizSpecificProps.showDisclaimer = true;
        vizSpecificProps.visualization = 'barchart';
        vizSpecificProps.version = '2.0.8';
        vizSpecificProps.components = [];
        vizSpecificProps.showMiniChartForContinuousAxis = true;

      } else if (vizType === 'filterpane') {
        // Filter pane is different - it uses qListObjectDef for each dimension instead of qHyperCubeDef
        // We'll handle this case separately below
      }

      // Create visualization object properties
      let vizProps: any;

      let vizId: string;

      if (vizType === 'filterpane') {
        // FIXED: Using exact structure from Qlik Cloud HAR capture for filter panes
        const filterDims = input.filterPaneProperties?.dimensions || input.dimensions.map(d => ({
          field: d.field,
          label: d.label,
          collapse: 'auto' as const,
          layoutMode: 'singleColumn' as const,
          showSearch: true
        }));

        // Generate unique ID for filter pane
        const generateId = () => Math.random().toString(36).substring(2, 8);

        // Create the filterpane container with exact structure from HAR
        const filterPaneProps: any = {
          qInfo: {
            qType: 'filterpane'
          },
          qExtendsId: '',
          qMetaDef: {},
          qStateName: '',
          showTitles: false,
          title: input.title || '',
          subtitle: '',
          footnote: '',
          disableNavMenu: false,
          showDetails: true,
          showDetailsExpression: false,
          visualization: 'filterpane',
          version: '1.1.2',
          qChildListDef: {
            qData: {}
          }
        };

        const filterPaneObject = await sheet.createChild(filterPaneProps);
        const filterPaneLayout = await filterPaneObject.getLayout();
        vizId = filterPaneLayout.qInfo.qId;

        // Now create listbox children for each dimension using exact HAR structure
        for (const dim of filterDims) {
          const cId = generateId();
          const fieldTitle = dim.label || dim.field;

          // Listbox properties - exact structure from HAR CreateChild call
          const listboxProps: any = {
            qListObjectDef: {
              showTitles: true,
              title: '',
              subtitle: '',
              footnote: '',
              disableNavMenu: false,
              showDetails: true,
              showDetailsExpression: false,
              qStateName: '',
              qDef: {
                qFieldDefs: [dim.field],
                qFieldLabels: [''],
                qSortCriterias: [{
                  qSortByState: 1,
                  qSortByLoadOrder: 1,
                  qSortByNumeric: 1,
                  qSortByAscii: 1
                }],
                autoSort: true,
                cId: cId
              },
              qOtherTotalSpec: {},
              qShowAlternatives: true,
              qDirectQuerySimplifiedView: false
            },
            showTitles: true,
            title: fieldTitle,
            subtitle: '',
            footnote: '',
            disableNavMenu: false,
            showDetails: true,
            showDetailsExpression: false,
            qStateName: '',
            qInfo: {
              qType: 'listbox'
            },
            visualization: 'listbox'
          };

          // Second parameter is the parent filterpane properties for update
          const filterPanePropsForUpdate: any = {
            qInfo: {
              qId: vizId,
              qType: 'filterpane'
            },
            qExtendsId: '',
            qMetaDef: {},
            qStateName: '',
            showTitles: false,
            title: input.title || '',
            subtitle: '',
            footnote: '',
            disableNavMenu: false,
            showDetails: true,
            showDetailsExpression: false,
            visualization: 'filterpane',
            version: '1.1.2',
            qChildListDef: {
              qData: {}
            }
          };

          try {
            await filterPaneObject.createChild(listboxProps, filterPanePropsForUpdate);
          } catch (childError) {
            // Try without the second parameter
            try {
              await filterPaneObject.createChild(listboxProps);
            } catch (childError2) {
              logger.warn(`[VisualizationService] Warning creating listbox for field ${dim.field}:`, childError2 as Error);
            }
          }
        }

      } else {
        // Standard visualizations use qHyperCubeDef
        // FIXED: Using exact structure from Qlik Cloud HAR capture
        vizProps = {
          qInfo: {
            qType: vizType
          },
          qExtendsId: '',
          qMetaDef: {},
          qStateName: '',
          qHyperCubeDef,
          showTitles: vizType !== 'kpi',  // KPIs typically don't show titles by default
          title: input.title,
          subtitle: '',
          footnote: '',
          ...vizSpecificProps
        };

        // Create the child object on the sheet
        const vizObject = await sheet.createChild(vizProps);
        const vizLayout = await vizObject.getLayout();
        vizId = vizLayout.qInfo.qId;
      }

      // Add to sheet cells
      sheetProps.cells = sheetProps.cells || [];
      const newCell: any = {
        name: vizId,
        type: vizType,
        col: input.position?.x ?? 0,
        row: input.position?.y ?? 0,
        colspan: input.position?.width ?? 12,
        rowspan: input.position?.height ?? 6,
        bounds: {
          x: input.position?.x ?? 0,
          y: input.position?.y ?? 0,
          width: input.position?.width ?? 12,
          height: input.position?.height ?? 6
        }
      };

      sheetProps.cells.push(newCell);
      await sheet.setProperties(sheetProps);
      await doc.doSave();

      await session.close();

      return {
        success: true,
        visualization: {
          id: vizId,
          title: input.title,
          type: input.visualizationType || 'sn-table',
          dimensions: input.dimensions.length,
          measures: input.measures.length
        },
        message: `Visualization "${input.title}" created successfully`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error creating visualization:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Delete a visualization from a sheet
   */
  async deleteVisualization(appId: string, sheetId: string, objectId: string): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(appId);
      const global = await session.open();
      const doc = await global.openDoc(appId);

      const sheet = await doc.getObject(sheetId);
      const sheetProps = await sheet.getProperties();

      // Remove from cells array
      sheetProps.cells = (sheetProps.cells || []).filter((cell: any) => cell.name !== objectId);
      await sheet.setProperties(sheetProps);

      // Destroy the object
      await doc.destroyObject(objectId);
      await doc.doSave();

      await session.close();

      return {
        success: true,
        message: `Visualization deleted successfully`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error deleting visualization:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  // ===== FIELD OPERATIONS =====

  /**
   * List all fields in the app
   */
  async listFields(input: FieldListInput): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const fieldList = await doc.getFieldList();

      let fields = fieldList.qFieldList.qItems.map((field: any) => ({
        name: field.qName,
        tags: field.qTags || [],
        isSystem: field.qName.startsWith('$'),
        cardinalNumber: field.qCardinal
      }));

      if (!input.includeSystem) {
        fields = fields.filter((f: any) => !f.isSystem);
      }

      await session.close();

      return {
        success: true,
        visualizations: fields,
        message: `Found ${fields.length} fields`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error listing fields:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Get field values
   */
  async getFieldValues(input: FieldValuesInput): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const field = await doc.getField(input.fieldName);
      const limit = Math.min(input.limit || 100, 10000);

      let data;
      if (input.searchTerm) {
        data = await field.select(input.searchTerm, false, 0);
      } else {
        data = await field.getData(0, limit, 10000);
      }

      const values = data.qMatrix?.map((row: any) => ({
        text: row[0].qText,
        number: row[0].qNum,
        elementNumber: row[0].qElemNumber
      })) || [];

      await session.close();

      return {
        success: true,
        visualization: {
          fieldName: input.fieldName,
          values,
          count: values.length
        },
        message: `Retrieved ${values.length} values for ${input.fieldName}`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error getting field values:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  // ===== MASTER ITEMS OPERATIONS =====

  /**
   * Create master dimension
   */
  async createMasterDimension(input: MasterDimensionInput): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const dimProps = {
        qInfo: {
          qType: 'dimension',
          qId: ''
        },
        qDim: {
          qFieldDefs: [input.field],
          qFieldLabels: [input.label]
        },
        qMetaDef: {
          title: input.label,
          description: input.description || '',
          tags: input.tags || []
        }
      };

      const dimension = await doc.createDimension(dimProps);
      const layout = await dimension.getLayout();
      await doc.doSave();
      await session.close();

      return {
        success: true,
        visualization: {
          id: layout.qInfo.qId,
          label: input.label,
          field: input.field
        },
        message: `Master dimension "${input.label}" created`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error creating master dimension:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Create master measure
   */
  async createMasterMeasure(input: MasterMeasureInput): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(input.appId);
      const global = await session.open();
      const doc = await global.openDoc(input.appId);

      const measureProps = {
        qInfo: {
          qType: 'measure',
          qId: ''
        },
        qMeasure: {
          qLabel: input.label,
          qDef: input.expression,
          qNumFormat: input.numberFormat || {}
        },
        qMetaDef: {
          title: input.label,
          description: input.description || '',
          tags: input.tags || []
        }
      };

      const measure = await doc.createMeasure(measureProps);
      const layout = await measure.getLayout();
      await doc.doSave();
      await session.close();

      return {
        success: true,
        visualization: {
          id: layout.qInfo.qId,
          label: input.label,
          expression: input.expression
        },
        message: `Master measure "${input.label}" created`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error creating master measure:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * List master dimensions
   */
  async listMasterDimensions(appId: string): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(appId);
      const global = await session.open();
      const doc = await global.openDoc(appId);

      const dimList = await doc.createSessionObject({
        qInfo: { qType: 'DimensionList' },
        qDimensionListDef: {
          qType: 'dimension',
          qData: {
            title: '/qMetaDef/title',
            tags: '/qMetaDef/tags',
            field: '/qDim/qFieldDefs/0'
          }
        }
      });

      const layout = await dimList.getLayout();
      const dimensions = layout.qDimensionList.qItems.map((item: any) => ({
        id: item.qInfo.qId,
        title: item.qMeta.title,
        field: item.qData.field,
        tags: item.qData.tags
      }));

      await session.close();

      return {
        success: true,
        visualizations: dimensions,
        message: `Found ${dimensions.length} master dimensions`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error listing master dimensions:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * List master measures
   */
  async listMasterMeasures(appId: string): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(appId);
      const global = await session.open();
      const doc = await global.openDoc(appId);

      const measureList = await doc.createSessionObject({
        qInfo: { qType: 'MeasureList' },
        qMeasureListDef: {
          qType: 'measure',
          qData: {
            title: '/qMetaDef/title',
            tags: '/qMetaDef/tags',
            expression: '/qMeasure/qDef'
          }
        }
      });

      const layout = await measureList.getLayout();
      const measures = layout.qMeasureList.qItems.map((item: any) => ({
        id: item.qInfo.qId,
        title: item.qMeta.title,
        expression: item.qData.expression,
        tags: item.qData.tags
      }));

      await session.close();

      return {
        success: true,
        visualizations: measures,
        message: `Found ${measures.length} master measures`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error listing master measures:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Delete master dimension or measure
   */
  async deleteMasterItem(appId: string, itemId: string): Promise<VisualizationResult> {
    let session: any;
    try {
      session = await this.createEngineSession(appId);
      const global = await session.open();
      const doc = await global.openDoc(appId);

      await doc.destroyDimension(itemId).catch(() => doc.destroyMeasure(itemId));
      await doc.doSave();
      await session.close();

      return {
        success: true,
        message: `Master item deleted successfully`
      };

    } catch (error) {
      if (session) {
        try { await session.close(); } catch (e) { /* ignore */ }
      }
      logger.error('[VisualizationService] Error deleting master item:', error as Error);
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
}
