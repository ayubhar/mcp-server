/**
 * Tool definitions for data operations and analysis
 */

export const DATA_TOOLS = {
  qlik_get_dataset_details: {
    name: 'qlik_get_dataset_details',
    description: 'Get detailed information about a dataset from the data catalog.',
    inputSchema: {
      type: 'object',
      properties: {
        datasetId: {
          type: 'string',
          description: 'Dataset ID'
        }
      },
      required: ['datasetId']
    }
  },

  qlik_apply_selections: {
    name: 'qlik_apply_selections',
    description: 'Apply selections/filters to a Qlik app',
    inputSchema: {
      type: 'object',
      properties: {
        appId: { type: 'string', description: 'App ID' },
        selections: {
          type: 'array',
          description: 'Selection criteria',
          items: {
            type: 'object',
            properties: {
              field: { type: 'string', description: 'Field name' },
              values: { type: 'array', description: 'Values to select' }
            },
            required: ['field']
          }
        }
      },
      required: ['appId', 'selections']
    }
  },

  qlik_clear_selections: {
    name: 'qlik_clear_selections',
    description: 'Clear all selections in an app',
    inputSchema: {
      type: 'object',
      properties: {
        appId: { type: 'string', description: 'App ID' }
      },
      required: ['appId']
    }
  },

  qlik_get_current_selections: {
    name: 'qlik_get_current_selections',
    description: 'Get current selections in an app',
    inputSchema: {
      type: 'object',
      properties: {
        appId: { type: 'string', description: 'App ID' }
      },
      required: ['appId']
    }
  },

  qlik_get_available_fields: {
    name: 'qlik_get_available_fields',
    description: 'Get all fields in an app',
    inputSchema: {
      type: 'object',
      properties: {
        appId: { type: 'string', description: 'App ID' }
      },
      required: ['appId']
    }
  }
};
