/**
 * Field Tools - Qlik Cloud Field Operations
 *
 * Tools for working with fields in Qlik Cloud apps.
 * Get field lists, field values, and field metadata.
 * Uses Engine API via enigma.js.
 *
 * Cloud only - field operations via Engine API.
 */

export const FIELD_TOOLS = {
  qlik_field_list: {
    name: 'qlik_field_list',
    description: 'List all fields in a Qlik Cloud app with metadata like field type, total count, and tags. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        includeSystem: {
          type: 'boolean',
          default: false,
          description: 'Include system fields (fields starting with $)'
        },
        includeTags: {
          type: 'boolean',
          default: true,
          description: 'Include field tags ($numeric, $text, $date, etc.)'
        }
      },
      required: ['appId']
    }
  },

  qlik_field_values: {
    name: 'qlik_field_values',
    description: 'Get distinct values for a specific field in a Qlik Cloud app. Returns up to 10,000 values by default. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        fieldName: {
          type: 'string',
          description: 'Name of the field'
        },
        limit: {
          type: 'number',
          default: 100,
          description: 'Maximum number of values to return (default: 100, max: 10000)'
        },
        searchTerm: {
          type: 'string',
          description: 'Optional search term to filter values'
        }
      },
      required: ['appId', 'fieldName']
    }
  },

  qlik_field_info: {
    name: 'qlik_field_info',
    description: 'Get detailed information about a specific field including cardinality, data type, and sample values. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        fieldName: {
          type: 'string',
          description: 'Name of the field'
        },
        includeSample: {
          type: 'boolean',
          default: true,
          description: 'Include sample values (first 20)'
        }
      },
      required: ['appId', 'fieldName']
    }
  }
};
