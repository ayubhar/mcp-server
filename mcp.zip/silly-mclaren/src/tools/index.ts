// ===== TOOLS INDEX =====
// Central registry of all tool definitions and registration logic

import { ToolDefinition, CLOUD_ONLY_TOOLS } from '../server/tool-registry.js';
import { APP_TOOLS } from './app-tools.js';
import { AUTOMATION_TOOLS } from './automation-tools.js';
import { RELOAD_TOOLS } from './reload-tools.js';
import { CATALOG_TOOLS } from './catalog-tools.js';
import { GOVERNANCE_TOOLS } from './governance-tools.js';
import { LINEAGE_TOOLS } from './lineage-tools.js';
import { DATA_TOOLS } from './data-tools.js';
import { MISC_TOOLS } from './misc-tools.js';
import { ANSWERS_TOOLS } from './answers-tools.js';
import { ALERTS_TOOLS } from './alerts-tools.js';
import { AUTOML_TOOLS } from './automl-tools.js';
import { SEARCH_TOOLS } from './search-tools.js';
import { SHEET_TOOLS } from './sheet-tools.js';
import { VISUALIZATION_TOOLS } from './visualization-tools.js';
import { FIELD_TOOLS } from './field-tools.js';
import { MASTER_ITEMS_TOOLS } from './master-items-tools.js';
import { HandlerRouter } from '../server/handler-router.js';
import { logger } from '../utils/logger.js';

/**
 * Universal tools - available on both cloud and on-premise
 */
export const UNIVERSAL_TOOLS = [
  'qlik_search',  // Unified search for both platforms
];

/**
 * Cloud-only tools - only available on Qlik Cloud
 */
export { CLOUD_ONLY_TOOLS };

/**
 * Export all tool definitions
 */
export {
  APP_TOOLS,
  AUTOMATION_TOOLS,
  RELOAD_TOOLS,
  CATALOG_TOOLS,
  GOVERNANCE_TOOLS,
  LINEAGE_TOOLS,
  DATA_TOOLS,
  MISC_TOOLS,
  ANSWERS_TOOLS,
  ALERTS_TOOLS,
  AUTOML_TOOLS,
  SEARCH_TOOLS,
  SHEET_TOOLS,
  VISUALIZATION_TOOLS,
  FIELD_TOOLS,
  MASTER_ITEMS_TOOLS
};

/**
 * Convert tool definitions to ToolDefinition format with handlers
 */
export function createToolDefinitions(
  router: HandlerRouter,
  platform: 'cloud' | 'on-premise'
): ToolDefinition[] {
  const tools: ToolDefinition[] = [];

  // ===== UNIFIED SEARCH TOOL (Both platforms) =====
  tools.push({
    name: SEARCH_TOOLS.qlik_search.name,
    description: SEARCH_TOOLS.qlik_search.description,
    inputSchema: SEARCH_TOOLS.qlik_search.inputSchema,
    handler: async (args) => await router.route('qlik_search', args),
    // No cloudOnly flag - available on both platforms
  });

  // ===== RELOAD TOOLS (Both platforms) =====
  tools.push({
    name: RELOAD_TOOLS.qlik_trigger_app_reload.name,
    description: RELOAD_TOOLS.qlik_trigger_app_reload.description,
    inputSchema: RELOAD_TOOLS.qlik_trigger_app_reload.inputSchema,
    handler: async (args) => await router.route('qlik_trigger_app_reload', args),
  });

  tools.push({
    name: RELOAD_TOOLS.qlik_get_reload_status.name,
    description: RELOAD_TOOLS.qlik_get_reload_status.description,
    inputSchema: RELOAD_TOOLS.qlik_get_reload_status.inputSchema,
    handler: async (args) => await router.route('qlik_get_reload_status', args),
  });

  tools.push({
    name: RELOAD_TOOLS.qlik_cancel_reload.name,
    description: RELOAD_TOOLS.qlik_cancel_reload.description,
    inputSchema: RELOAD_TOOLS.qlik_cancel_reload.inputSchema,
    handler: async (args) => await router.route('qlik_cancel_reload', args),
  });

  // ===== CATALOG TOOLS (Both platforms - Spaces for Cloud, Streams for On-Prem) =====
  tools.push({
    name: CATALOG_TOOLS.qlik_get_spaces_catalog.name,
    description: CATALOG_TOOLS.qlik_get_spaces_catalog.description,
    inputSchema: CATALOG_TOOLS.qlik_get_spaces_catalog.inputSchema,
    handler: async (args) => await router.route('qlik_get_spaces_catalog', args),
  });

  // ===== GOVERNANCE TOOLS (Both platforms) =====
  tools.push({
    name: GOVERNANCE_TOOLS.qlik_get_tenant_info.name,
    description: GOVERNANCE_TOOLS.qlik_get_tenant_info.description,
    inputSchema: GOVERNANCE_TOOLS.qlik_get_tenant_info.inputSchema,
    handler: async (args) => await router.route('qlik_get_tenant_info', args),
  });

  tools.push({
    name: GOVERNANCE_TOOLS.qlik_get_user_info.name,
    description: GOVERNANCE_TOOLS.qlik_get_user_info.description,
    inputSchema: GOVERNANCE_TOOLS.qlik_get_user_info.inputSchema,
    handler: async (args) => await router.route('qlik_get_user_info', args),
  });

  tools.push({
    name: GOVERNANCE_TOOLS.qlik_search_users.name,
    description: GOVERNANCE_TOOLS.qlik_search_users.description,
    inputSchema: GOVERNANCE_TOOLS.qlik_search_users.inputSchema,
    handler: async (args) => await router.route('qlik_search_users', args),
  });

  tools.push({
    name: GOVERNANCE_TOOLS.qlik_health_check.name,
    description: GOVERNANCE_TOOLS.qlik_health_check.description,
    inputSchema: GOVERNANCE_TOOLS.qlik_health_check.inputSchema,
    handler: async (args) => await router.route('qlik_health_check', args),
  });

  tools.push({
    name: GOVERNANCE_TOOLS.qlik_get_license_info.name,
    description: GOVERNANCE_TOOLS.qlik_get_license_info.description,
    inputSchema: GOVERNANCE_TOOLS.qlik_get_license_info.inputSchema,
    handler: async (args) => await router.route('qlik_get_license_info', args),
  });

  // ===== DATA TOOLS - Engine API (Both platforms) =====
  tools.push({
    name: DATA_TOOLS.qlik_apply_selections.name,
    description: DATA_TOOLS.qlik_apply_selections.description,
    inputSchema: DATA_TOOLS.qlik_apply_selections.inputSchema,
    handler: async (args) => await router.route('qlik_apply_selections', args),
  });

  tools.push({
    name: DATA_TOOLS.qlik_clear_selections.name,
    description: DATA_TOOLS.qlik_clear_selections.description,
    inputSchema: DATA_TOOLS.qlik_clear_selections.inputSchema,
    handler: async (args) => await router.route('qlik_clear_selections', args),
  });

  tools.push({
    name: DATA_TOOLS.qlik_get_current_selections.name,
    description: DATA_TOOLS.qlik_get_current_selections.description,
    inputSchema: DATA_TOOLS.qlik_get_current_selections.inputSchema,
    handler: async (args) => await router.route('qlik_get_current_selections', args),
  });

  tools.push({
    name: DATA_TOOLS.qlik_get_available_fields.name,
    description: DATA_TOOLS.qlik_get_available_fields.description,
    inputSchema: DATA_TOOLS.qlik_get_available_fields.inputSchema,
    handler: async (args) => await router.route('qlik_get_available_fields', args),
  });

  // ===== APP TOOLS (Both platforms) =====
  tools.push({
    name: APP_TOOLS.qlik_generate_app.name,
    description: APP_TOOLS.qlik_generate_app.description,
    inputSchema: APP_TOOLS.qlik_generate_app.inputSchema,
    handler: async (args) => await router.route('qlik_generate_app', args),
  });

  // ===== MISC TOOLS - NL/Insight Advisor (Both platforms) =====
  tools.push({
    name: MISC_TOOLS.qlik_insight_advisor.name,
    description: MISC_TOOLS.qlik_insight_advisor.description,
    inputSchema: MISC_TOOLS.qlik_insight_advisor.inputSchema,
    handler: async (args) => await router.route('qlik_insight_advisor', args),
  });

  tools.push({
    name: MISC_TOOLS.qlik_get_reload_info.name,
    description: MISC_TOOLS.qlik_get_reload_info.description,
    inputSchema: MISC_TOOLS.qlik_get_reload_info.inputSchema,
    handler: async (args) => await router.route('qlik_get_reload_info', args),
  });

  // ===== CLOUD-ONLY TOOLS =====
  if (platform === 'cloud') {
    // ===== LINEAGE TOOLS (Cloud only) =====
    tools.push({
      name: LINEAGE_TOOLS.qlik_get_lineage.name,
      description: LINEAGE_TOOLS.qlik_get_lineage.description,
      inputSchema: LINEAGE_TOOLS.qlik_get_lineage.inputSchema,
      handler: async (args) => await router.route('qlik_get_lineage', args),
      cloudOnly: true,
    });

    // ===== DATA TOOLS - Cloud REST APIs (Cloud only) =====
    tools.push({
      name: DATA_TOOLS.qlik_get_dataset_details.name,
      description: DATA_TOOLS.qlik_get_dataset_details.description,
      inputSchema: DATA_TOOLS.qlik_get_dataset_details.inputSchema,
      handler: async (args) => await router.route('qlik_get_dataset_details', args),
      cloudOnly: true,
    });

    // ===== QLIK ANSWERS TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(ANSWERS_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== QLIK ALERTS TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(ALERTS_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== AUTOML TOOLS (Cloud only) =====
    for (const tool of AUTOML_TOOLS) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== AUTOMATION TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(AUTOMATION_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== SHEET TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(SHEET_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== VISUALIZATION TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(VISUALIZATION_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== FIELD TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(FIELD_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }

    // ===== MASTER ITEMS TOOLS (Cloud only) =====
    for (const [key, tool] of Object.entries(MASTER_ITEMS_TOOLS)) {
      tools.push({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
        handler: async (args) => await router.route(tool.name, args),
        cloudOnly: true,
      });
    }
  }

  return tools;
}

/**
 * Register all tools based on platform
 */
export function registerAllTools(
  registry: any,
  router: HandlerRouter,
  platform: 'cloud' | 'on-premise'
): void {
  const tools = createToolDefinitions(router, platform);
  registry.registerTools(tools);
}

/**
 * Get adapted tools list for the current platform
 */
export function getAdaptedTools(platform: 'cloud' | 'on-premise'): string[] {
  if (platform === 'cloud') {
    return [...UNIVERSAL_TOOLS, ...CLOUD_ONLY_TOOLS];
  } else {
    return UNIVERSAL_TOOLS;
  }
}

/**
 * Export all tool arrays
 */
export const ADAPTED_TOOLS = {
  universal: UNIVERSAL_TOOLS,
  cloudOnly: CLOUD_ONLY_TOOLS,
};
