/**
 * Master Items Tools - Qlik Cloud Master Dimensions and Measures
 *
 * Tools for managing master dimensions and measures in the Qlik Cloud app library.
 * Master items can be reused across multiple visualizations.
 * Uses Engine API via enigma.js (CreateDimension, CreateMeasure methods).
 *
 * Cloud only - master items via Engine API.
 */

export const MASTER_ITEMS_TOOLS = {
  // ===== MASTER DIMENSIONS =====

  qlik_master_dimension_create: {
    name: 'qlik_master_dimension_create',
    description: 'Create a master dimension in the app library. Master dimensions can be reused across visualizations. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        field: {
          type: 'string',
          description: 'Field name or expression for the dimension'
        },
        label: {
          type: 'string',
          description: 'Display label for the dimension'
        },
        description: {
          type: 'string',
          description: 'Description of the dimension (optional)'
        },
        tags: {
          type: 'array',
          items: { type: 'string' },
          description: 'Tags for categorizing the dimension (optional)'
        }
      },
      required: ['appId', 'field', 'label']
    }
  },

  qlik_master_dimension_list: {
    name: 'qlik_master_dimension_list',
    description: 'List all master dimensions in a Qlik Cloud app library. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        }
      },
      required: ['appId']
    }
  },

  qlik_master_dimension_get: {
    name: 'qlik_master_dimension_get',
    description: 'Get detailed information about a specific master dimension. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        dimensionId: {
          type: 'string',
          description: 'ID of the master dimension'
        }
      },
      required: ['appId', 'dimensionId']
    }
  },

  qlik_master_dimension_update: {
    name: 'qlik_master_dimension_update',
    description: 'Update properties of an existing master dimension. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        dimensionId: {
          type: 'string',
          description: 'ID of the master dimension'
        },
        field: {
          type: 'string',
          description: 'New field name or expression (optional)'
        },
        label: {
          type: 'string',
          description: 'New display label (optional)'
        },
        description: {
          type: 'string',
          description: 'New description (optional)'
        },
        tags: {
          type: 'array',
          items: { type: 'string' },
          description: 'New tags (optional)'
        }
      },
      required: ['appId', 'dimensionId']
    }
  },

  qlik_master_dimension_delete: {
    name: 'qlik_master_dimension_delete',
    description: 'Delete a master dimension from the app library. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        dimensionId: {
          type: 'string',
          description: 'ID of the master dimension to delete'
        }
      },
      required: ['appId', 'dimensionId']
    }
  },

  // ===== MASTER MEASURES =====

  qlik_master_measure_create: {
    name: 'qlik_master_measure_create',
    description: 'Create a master measure in the app library. Master measures can be reused across visualizations. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        expression: {
          type: 'string',
          description: 'Measure expression (e.g., "Sum(Sales)", "Avg(Price)")'
        },
        label: {
          type: 'string',
          description: 'Display label for the measure'
        },
        description: {
          type: 'string',
          description: 'Description of the measure (optional)'
        },
        tags: {
          type: 'array',
          items: { type: 'string' },
          description: 'Tags for categorizing the measure (optional)'
        },
        numberFormat: {
          type: 'object',
          description: 'Number formatting options (optional)',
          properties: {
            type: {
              type: 'string',
              enum: ['auto', 'number', 'currency', 'percent'],
              description: 'Format type'
            },
            decimals: {
              type: 'number',
              description: 'Number of decimal places'
            }
          }
        }
      },
      required: ['appId', 'expression', 'label']
    }
  },

  qlik_master_measure_list: {
    name: 'qlik_master_measure_list',
    description: 'List all master measures in a Qlik Cloud app library. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        }
      },
      required: ['appId']
    }
  },

  qlik_master_measure_get: {
    name: 'qlik_master_measure_get',
    description: 'Get detailed information about a specific master measure. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        measureId: {
          type: 'string',
          description: 'ID of the master measure'
        }
      },
      required: ['appId', 'measureId']
    }
  },

  qlik_master_measure_update: {
    name: 'qlik_master_measure_update',
    description: 'Update properties of an existing master measure. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        measureId: {
          type: 'string',
          description: 'ID of the master measure'
        },
        expression: {
          type: 'string',
          description: 'New measure expression (optional)'
        },
        label: {
          type: 'string',
          description: 'New display label (optional)'
        },
        description: {
          type: 'string',
          description: 'New description (optional)'
        },
        tags: {
          type: 'array',
          items: { type: 'string' },
          description: 'New tags (optional)'
        }
      },
      required: ['appId', 'measureId']
    }
  },

  qlik_master_measure_delete: {
    name: 'qlik_master_measure_delete',
    description: 'Delete a master measure from the app library. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        measureId: {
          type: 'string',
          description: 'ID of the master measure to delete'
        }
      },
      required: ['appId', 'measureId']
    }
  }
};
