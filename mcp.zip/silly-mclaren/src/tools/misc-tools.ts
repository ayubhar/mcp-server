/**
 * Tool definitions for miscellaneous operations (NL queries, bulk operations, etc.)
 */

export const MISC_TOOLS = {
  qlik_insight_advisor: {
    name: 'qlik_insight_advisor',
    description: `Ask natural language questions about Qlik data using Insight Advisor.

**Flow (no Claude API key needed):**

**Option A - With appId (recommended, works on all tenants):**
1. Call with "text" + "appId" → Returns app model (fields, measures, dimensions)
2. Call with "refinedQuestion" + "appId" using exact field names → Returns data

**Option B - Auto app detection (requires Qlik Answers enabled):**
1. Call with just "text" → Tries to identify app automatically
2. If 405 error, use Option A instead

**Example:**
Step 1: { "text": "show sales", "appId": "abc123" }
→ Returns model with fields like "Revenue", "Sales Region"

Step 2: { "appId": "abc123", "refinedQuestion": "show Revenue by Sales Region" }
→ Returns actual data and visualizations

**If you get 405 error:** Use qlik_search_apps first to find the app ID.`,
    inputSchema: {
      type: 'object',
      properties: {
        text: {
          type: 'string',
          description: 'Natural language question'
        },
        refinedQuestion: {
          type: 'string',
          description: 'Refined question using exact field names from model (Step 2)'
        },
        appId: {
          type: 'string',
          description: 'App ID - provide this to skip auto-detection and get model directly'
        },
        conversationId: {
          type: 'string',
          description: 'Conversation ID for multi-app selection'
        },
        selectedAppId: {
          type: 'string',
          description: 'App ID when continuing after multiple app selection'
        }
      },
      required: ['text']
    }
  },

  qlik_get_reload_info: {
    name: 'qlik_get_reload_info',
    description: `Get app reload history and status`,
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'App ID'
        },
        limit: {
          type: 'number',
          default: 10,
          description: 'Number of reload records to return'
        }
      },
      required: ['appId']
    }
  }
};
