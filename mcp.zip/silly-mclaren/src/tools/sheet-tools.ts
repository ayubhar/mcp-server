/**
 * Sheet Tools - Qlik Cloud Sheet Management
 *
 * Tools for creating, reading, updating, and deleting sheets in Qlik Cloud apps.
 * Uses Engine API via enigma.js for sheet operations.
 *
 * Cloud only - sheets are managed via Engine API.
 */

export const SHEET_TOOLS = {
  qlik_sheet_create: {
    name: 'qlik_sheet_create',
    description: 'Create a new sheet in a Qlik Cloud app. Sheets are the main containers for visualizations in Qlik Sense. You can specify the title, description, and optional grid layout. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app where the sheet will be created'
        },
        title: {
          type: 'string',
          description: 'Title of the sheet'
        },
        description: {
          type: 'string',
          description: 'Description of the sheet (optional)'
        },
        columns: {
          type: 'number',
          default: 24,
          description: 'Number of columns in the sheet grid (default: 24)'
        },
        rows: {
          type: 'number',
          default: 12,
          description: 'Number of rows in the sheet grid (default: 12)'
        },
        rank: {
          type: 'number',
          description: 'Display order/rank of the sheet (lower numbers appear first)'
        }
      },
      required: ['appId', 'title']
    }
  },

  qlik_sheet_list: {
    name: 'qlik_sheet_list',
    description: 'List all sheets in a Qlik Cloud app. Returns sheet IDs, titles, descriptions, and basic metadata. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        includeObjects: {
          type: 'boolean',
          default: false,
          description: 'Include list of objects/visualizations on each sheet'
        }
      },
      required: ['appId']
    }
  },

  qlik_sheet_get: {
    name: 'qlik_sheet_get',
    description: 'Get detailed information about a specific sheet in a Qlik Cloud app, including its properties, layout, and optionally the visualizations it contains. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet to retrieve'
        },
        includeObjects: {
          type: 'boolean',
          default: true,
          description: 'Include detailed information about visualizations on the sheet'
        }
      },
      required: ['appId', 'sheetId']
    }
  },

  qlik_sheet_update: {
    name: 'qlik_sheet_update',
    description: 'Update properties of an existing sheet in a Qlik Cloud app. You can change the title, description, grid layout, or rank. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet to update'
        },
        title: {
          type: 'string',
          description: 'New title for the sheet (optional)'
        },
        description: {
          type: 'string',
          description: 'New description for the sheet (optional)'
        },
        columns: {
          type: 'number',
          description: 'New number of columns in the grid (optional)'
        },
        rows: {
          type: 'number',
          description: 'New number of rows in the grid (optional)'
        },
        rank: {
          type: 'number',
          description: 'New display order/rank (optional)'
        }
      },
      required: ['appId', 'sheetId']
    }
  },

  qlik_sheet_delete: {
    name: 'qlik_sheet_delete',
    description: 'Delete a sheet from a Qlik Cloud app. This will remove the sheet and all its visualizations. Use with caution. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet to delete'
        }
      },
      required: ['appId', 'sheetId']
    }
  },

  qlik_sheet_duplicate: {
    name: 'qlik_sheet_duplicate',
    description: 'Duplicate an existing sheet in a Qlik Cloud app, creating a copy with all its visualizations. The new sheet will have a modified title. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet to duplicate'
        },
        newTitle: {
          type: 'string',
          description: 'Title for the duplicated sheet (optional, defaults to "Copy of [original title]")'
        }
      },
      required: ['appId', 'sheetId']
    }
  }
};
