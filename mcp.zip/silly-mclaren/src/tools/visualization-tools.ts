/**
 * Visualization Tools - Qlik Cloud Visualization Management
 *
 * Tools for creating, reading, updating, and deleting visualizations (charts/objects) in Qlik Cloud apps.
 * Currently supports sn-table (straight table) visualizations.
 * Uses Engine API via enigma.js.
 *
 * Cloud only - visualizations are managed via Engine API.
 */

export const VISUALIZATION_TOOLS = {
  qlik_visualization_create: {
    name: 'qlik_visualization_create',
    description: 'Create a new visualization (table, pie chart, bar chart, KPI, filter pane) on a sheet in a Qlik Cloud app. Supports dimensions, measures, filters, appearance properties, and positioning. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet where the visualization will be created'
        },
        title: {
          type: 'string',
          description: 'Title of the visualization'
        },
        visualizationType: {
          type: 'string',
          enum: ['sn-table', 'straight-table', 'table', 'pivot-table', 'piechart', 'kpi', 'barchart', 'filterpane'],
          default: 'sn-table',
          description: 'Type of visualization: sn-table (straight table - modern), table (legacy table), pivot-table (pivot table), piechart, kpi, barchart, filterpane'
        },
        dimensions: {
          type: 'array',
          description: 'Array of dimension definitions (field names or expressions)',
          items: {
            type: 'object',
            properties: {
              field: {
                type: 'string',
                description: 'Field name or expression (e.g., "Country" or "=Year")'
              },
              label: {
                type: 'string',
                description: 'Label for the dimension (optional)'
              },
              columnProps: {
                type: 'object',
                description: 'Column-specific properties for table visualizations (sn-table, table, pivot-table)',
                properties: {
                  label: {
                    type: 'string',
                    description: 'Custom column header label'
                  },
                  showColumnIf: {
                    type: 'string',
                    description: 'Show column if expression (e.g., "1=1" always shows, "Count(CarID) > 5" conditional)'
                  },
                  backgroundColorExpression: {
                    type: 'string',
                    description: 'Background color expression returning color code (e.g., "if(Sum(Price) > 30000, \'#ff6b6b\', \'#51cf66\')")'
                  },
                  textColorExpression: {
                    type: 'string',
                    description: 'Text/foreground color expression returning color code'
                  },
                  textAlign: {
                    type: 'object',
                    description: 'Text alignment configuration',
                    properties: {
                      auto: {
                        type: 'boolean',
                        default: true,
                        description: 'Use automatic alignment'
                      },
                      align: {
                        type: 'string',
                        enum: ['left', 'center', 'right'],
                        default: 'left',
                        description: 'Alignment when auto is false'
                      }
                    }
                  },
                  columnWidth: {
                    type: 'object',
                    description: 'Column width configuration',
                    properties: {
                      type: {
                        type: 'string',
                        enum: ['auto', 'fitToContent', 'pixels', 'percentage'],
                        default: 'auto',
                        description: 'Width type'
                      },
                      pixels: {
                        type: 'string',
                        description: 'Width in pixels (when type is pixels)'
                      },
                      percentage: {
                        type: 'string',
                        description: 'Width as percentage (when type is percentage)'
                      }
                    }
                  }
                }
              }
            },
            required: ['field']
          }
        },
        measures: {
          type: 'array',
          description: 'Array of measure definitions (expressions)',
          items: {
            type: 'object',
            properties: {
              expression: {
                type: 'string',
                description: 'Measure expression (e.g., "Sum(Sales)")'
              },
              label: {
                type: 'string',
                description: 'Label for the measure (optional)'
              },
              columnProps: {
                type: 'object',
                description: 'Column-specific properties for table visualizations (sn-table, table, pivot-table)',
                properties: {
                  label: {
                    type: 'string',
                    description: 'Custom column header label'
                  },
                  showColumnIf: {
                    type: 'string',
                    description: 'Show column if expression (e.g., "1=1" always shows, "Sum(Sales) > 1000" conditional)'
                  },
                  backgroundColorExpression: {
                    type: 'string',
                    description: 'Background color expression returning color code (e.g., "if(Sum(Price) > 30000, \'#ff6b6b\', \'#51cf66\')")'
                  },
                  textColorExpression: {
                    type: 'string',
                    description: 'Text/foreground color expression returning color code'
                  },
                  textAlign: {
                    type: 'object',
                    description: 'Text alignment configuration',
                    properties: {
                      auto: {
                        type: 'boolean',
                        default: true,
                        description: 'Use automatic alignment'
                      },
                      align: {
                        type: 'string',
                        enum: ['left', 'center', 'right'],
                        default: 'left',
                        description: 'Alignment when auto is false'
                      }
                    }
                  },
                  columnWidth: {
                    type: 'object',
                    description: 'Column width configuration',
                    properties: {
                      type: {
                        type: 'string',
                        enum: ['auto', 'fitToContent', 'pixels', 'percentage'],
                        default: 'auto',
                        description: 'Width type'
                      },
                      pixels: {
                        type: 'string',
                        description: 'Width in pixels (when type is pixels)'
                      },
                      percentage: {
                        type: 'string',
                        description: 'Width as percentage (when type is percentage)'
                      }
                    }
                  }
                }
              }
            },
            required: ['expression']
          }
        },
        position: {
          type: 'object',
          description: 'Position and size on the sheet grid (optional)',
          properties: {
            x: { type: 'number', description: 'X position (column)' },
            y: { type: 'number', description: 'Y position (row)' },
            width: { type: 'number', description: 'Width in grid units' },
            height: { type: 'number', description: 'Height in grid units' }
          }
        },
        tableProperties: {
          type: 'object',
          description: 'Table-specific properties for styling and behavior (optional)',
          properties: {
            totals: {
              type: 'object',
              description: 'Totals row configuration',
              properties: {
                show: {
                  type: 'boolean',
                  description: 'Show totals row (default: false)',
                  default: false
                },
                position: {
                  type: 'string',
                  enum: ['top', 'bottom'],
                  description: 'Position of totals row (default: bottom)',
                  default: 'bottom'
                },
                label: {
                  type: 'string',
                  description: 'Label for totals row (default: empty)',
                  default: ''
                }
              }
            },
            styling: {
              type: 'object',
              description: 'Visual styling options',
              properties: {
                header: {
                  type: 'object',
                  properties: {
                    fontSize: { type: 'string', description: 'Font size (e.g., "14px")' },
                    fontColor: {
                      type: 'object',
                      properties: {
                        color: { type: 'string', description: 'Color value (e.g., "#333333")' }
                      }
                    },
                    backgroundColor: {
                      type: 'object',
                      properties: {
                        color: { type: 'string', description: 'Background color (e.g., "#f0f0f0")' }
                      }
                    }
                  }
                },
                rows: {
                  type: 'object',
                  properties: {
                    fontSize: { type: 'string', description: 'Font size (e.g., "12px")' },
                    padding: { type: 'string', description: 'Row padding (e.g., "normal", "compact", "comfortable")' }
                  }
                }
              }
            }
          }
        },
        pieChartProperties: {
          type: 'object',
          description: 'Pie chart-specific properties (only for piechart visualizations)',
          properties: {
            appearance: {
              type: 'object',
              description: 'Visual appearance settings for pie chart',
              properties: {
                style: {
                  type: 'string',
                  enum: ['pie', 'donut'],
                  default: 'pie',
                  description: 'Chart style - pie (full circle) or donut (hollow center)'
                },
                dimensionLabels: {
                  type: 'boolean',
                  default: true,
                  description: 'Show dimension labels on the chart'
                },
                valueLabels: {
                  type: 'boolean',
                  default: true,
                  description: 'Show value labels on the chart'
                },
                legend: {
                  type: 'object',
                  description: 'Legend configuration',
                  properties: {
                    show: {
                      type: 'boolean',
                      default: true,
                      description: 'Show legend'
                    },
                    position: {
                      type: 'string',
                      enum: ['right', 'left', 'top', 'bottom'],
                      default: 'right',
                      description: 'Legend position'
                    }
                  }
                },
                colors: {
                  type: 'object',
                  description: 'Color configuration',
                  properties: {
                    auto: {
                      type: 'boolean',
                      default: true,
                      description: 'Use automatic colors'
                    },
                    customColors: {
                      type: 'array',
                      items: { type: 'string' },
                      description: 'Custom color palette (hex colors, e.g., ["#FF5733", "#33FF57"])'
                    }
                  }
                }
              }
            },
            filters: {
              type: 'array',
              description: 'Data filters to apply to the visualization',
              items: {
                type: 'object',
                properties: {
                  field: {
                    type: 'string',
                    description: 'Field name to filter on'
                  },
                  values: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'Values to filter by'
                  }
                },
                required: ['field', 'values']
              }
            }
          }
        },
        kpiProperties: {
          type: 'object',
          description: 'KPI-specific properties (only for kpi visualizations)',
          properties: {
            appearance: {
              type: 'object',
              description: 'Visual appearance settings for KPI',
              properties: {
                textAlign: {
                  type: 'string',
                  enum: ['left', 'center', 'right'],
                  default: 'center',
                  description: 'Text alignment'
                },
                fontSize: {
                  type: 'string',
                  enum: ['S', 'M', 'L'],
                  default: 'M',
                  description: 'Font size (S=small, M=medium, L=large)'
                },
                showMeasureTitle: {
                  type: 'boolean',
                  default: true,
                  description: 'Show measure title'
                },
                backgroundColor: {
                  type: 'string',
                  description: 'Background color (hex code, e.g., "#FFFFFF")'
                },
                backgroundExpression: {
                  type: 'string',
                  description: 'Expression for dynamic background color'
                },
                conditionalColor: {
                  type: 'object',
                  description: 'Conditional coloring based on expressions',
                  properties: {
                    useConditionalColor: {
                      type: 'boolean',
                      default: false,
                      description: 'Enable conditional coloring'
                    },
                    conditions: {
                      type: 'array',
                      description: 'Array of color conditions',
                      items: {
                        type: 'object',
                        properties: {
                          condition: {
                            type: 'string',
                            description: 'Expression that evaluates to true/false'
                          },
                          color: {
                            type: 'string',
                            description: 'Color to apply when condition is true (hex code)'
                          }
                        },
                        required: ['condition', 'color']
                      }
                    }
                  }
                }
              }
            },
            navigation: {
              type: 'object',
              description: 'Navigation/linking settings',
              properties: {
                useLink: {
                  type: 'boolean',
                  default: false,
                  description: 'Enable linking to another sheet'
                },
                sheetLink: {
                  type: 'string',
                  description: 'Sheet ID to navigate to when clicked'
                },
                openInNewTab: {
                  type: 'boolean',
                  default: true,
                  description: 'Open link in new tab'
                }
              }
            }
          }
        },
        barChartProperties: {
          type: 'object',
          description: 'Bar chart-specific properties (only for barchart visualizations)',
          properties: {
            appearance: {
              type: 'object',
              description: 'Visual appearance settings for bar chart',
              properties: {
                orientation: {
                  type: 'string',
                  enum: ['vertical', 'horizontal'],
                  default: 'vertical',
                  description: 'Chart orientation'
                },
                barGrouping: {
                  type: 'string',
                  enum: ['grouped', 'stacked'],
                  default: 'grouped',
                  description: 'Bar grouping mode'
                },
                colors: {
                  type: 'object',
                  description: 'Color configuration',
                  properties: {
                    auto: {
                      type: 'boolean',
                      default: true,
                      description: 'Use automatic colors'
                    },
                    mode: {
                      type: 'string',
                      enum: ['primary', 'byDimension', 'byExpression', 'byMeasure'],
                      default: 'primary',
                      description: 'Color mode'
                    },
                    customColors: {
                      type: 'array',
                      items: { type: 'string' },
                      description: 'Custom color palette (hex colors)'
                    }
                  }
                },
                legend: {
                  type: 'object',
                  description: 'Legend configuration',
                  properties: {
                    show: {
                      type: 'boolean',
                      default: true,
                      description: 'Show legend'
                    },
                    position: {
                      type: 'string',
                      enum: ['auto', 'right', 'left', 'top', 'bottom'],
                      default: 'auto',
                      description: 'Legend position'
                    }
                  }
                }
              }
            },
            dataLabels: {
              type: 'object',
              description: 'Data label settings',
              properties: {
                show: {
                  type: 'boolean',
                  default: false,
                  description: 'Show data labels on bars'
                },
                showSegmentLabels: {
                  type: 'boolean',
                  default: false,
                  description: 'Show segment labels (stacked mode only)'
                },
                showTotalLabels: {
                  type: 'boolean',
                  default: false,
                  description: 'Show total labels (stacked mode only)'
                }
              }
            },
            axes: {
              type: 'object',
              description: 'Axis configuration',
              properties: {
                dimensionAxis: {
                  type: 'object',
                  properties: {
                    show: {
                      type: 'string',
                      enum: ['all', 'labels', 'title', 'none'],
                      default: 'all',
                      description: 'What to show on dimension axis'
                    },
                    label: {
                      type: 'string',
                      enum: ['auto', 'horizontal', 'tilted'],
                      default: 'auto',
                      description: 'Label orientation'
                    }
                  }
                },
                measureAxis: {
                  type: 'object',
                  properties: {
                    show: {
                      type: 'string',
                      enum: ['all', 'labels', 'title', 'none'],
                      default: 'all',
                      description: 'What to show on measure axis'
                    },
                    autoMinMax: {
                      type: 'boolean',
                      default: true,
                      description: 'Automatically determine min/max values'
                    },
                    min: {
                      type: 'number',
                      description: 'Minimum value (if autoMinMax is false)'
                    },
                    max: {
                      type: 'number',
                      description: 'Maximum value (if autoMinMax is false)'
                    }
                  }
                }
              }
            },
            gridLines: {
              type: 'object',
              description: 'Grid line configuration',
              properties: {
                auto: {
                  type: 'boolean',
                  default: true,
                  description: 'Automatic grid line spacing'
                },
                spacing: {
                  type: 'number',
                  default: 2,
                  description: 'Grid line spacing (0-3)'
                }
              }
            }
          }
        },
        filterPaneProperties: {
          type: 'object',
          description: 'Filter pane-specific properties (only for filterpane visualizations)',
          properties: {
            dimensions: {
              type: 'array',
              description: 'Array of dimension/field configurations for the filter pane',
              items: {
                type: 'object',
                properties: {
                  field: {
                    type: 'string',
                    description: 'Field name to add as a filter'
                  },
                  label: {
                    type: 'string',
                    description: 'Display label for the filter'
                  },
                  collapse: {
                    type: 'string',
                    enum: ['auto', 'always', 'never'],
                    default: 'auto',
                    description: 'Collapse behavior'
                  },
                  layoutMode: {
                    type: 'string',
                    enum: ['singleColumn', 'grid'],
                    default: 'singleColumn',
                    description: 'Layout mode for values'
                  },
                  showSearch: {
                    type: 'boolean',
                    default: true,
                    description: 'Show search box'
                  }
                },
                required: ['field']
              }
            },
            appearance: {
              type: 'object',
              description: 'Appearance settings',
              properties: {
                collapseBehavior: {
                  type: 'string',
                  enum: ['auto', 'always', 'never'],
                  default: 'auto',
                  description: 'Overall collapse behavior'
                }
              }
            }
          }
        }
      },
      required: ['appId', 'sheetId', 'title', 'dimensions', 'measures']
    }
  },

  qlik_visualization_list: {
    name: 'qlik_visualization_list',
    description: 'List all visualizations on a specific sheet in a Qlik Cloud app. Returns visualization IDs, types, titles, and basic properties. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet'
        },
        includeData: {
          type: 'boolean',
          default: false,
          description: 'Include sample data from visualizations (can be slow for many objects)'
        }
      },
      required: ['appId', 'sheetId']
    }
  },

  qlik_visualization_get: {
    name: 'qlik_visualization_get',
    description: 'Get detailed information about a specific visualization, including its properties, dimensions, measures, and optionally sample data. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        objectId: {
          type: 'string',
          description: 'ID of the visualization object'
        },
        includeData: {
          type: 'boolean',
          default: true,
          description: 'Include sample data (first 100 rows)'
        },
        dataLimit: {
          type: 'number',
          default: 100,
          description: 'Maximum rows of data to retrieve'
        }
      },
      required: ['appId', 'objectId']
    }
  },

  qlik_visualization_update: {
    name: 'qlik_visualization_update',
    description: 'Update properties of an existing visualization. Can change title, dimensions, measures, or position. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        objectId: {
          type: 'string',
          description: 'ID of the visualization to update'
        },
        title: {
          type: 'string',
          description: 'New title (optional)'
        },
        dimensions: {
          type: 'array',
          description: 'New dimensions array (replaces existing, optional)',
          items: {
            type: 'object',
            properties: {
              field: { type: 'string' },
              label: { type: 'string' },
              columnProps: {
                type: 'object',
                description: 'Column-specific properties (label, showColumnIf, backgroundColorExpression, textColorExpression, textAlign, columnWidth)',
                properties: {
                  label: { type: 'string' },
                  showColumnIf: { type: 'string' },
                  backgroundColorExpression: { type: 'string' },
                  textColorExpression: { type: 'string' },
                  textAlign: {
                    type: 'object',
                    properties: {
                      auto: { type: 'boolean' },
                      align: { type: 'string', enum: ['left', 'center', 'right'] }
                    }
                  },
                  columnWidth: {
                    type: 'object',
                    properties: {
                      type: { type: 'string', enum: ['auto', 'fitToContent', 'pixels', 'percentage'] },
                      pixels: { type: 'string' },
                      percentage: { type: 'string' }
                    }
                  }
                }
              }
            },
            required: ['field']
          }
        },
        measures: {
          type: 'array',
          description: 'New measures array (replaces existing, optional)',
          items: {
            type: 'object',
            properties: {
              expression: { type: 'string' },
              label: { type: 'string' },
              columnProps: {
                type: 'object',
                description: 'Column-specific properties (label, showColumnIf, backgroundColorExpression, textColorExpression, textAlign, columnWidth)',
                properties: {
                  label: { type: 'string' },
                  showColumnIf: { type: 'string' },
                  backgroundColorExpression: { type: 'string' },
                  textColorExpression: { type: 'string' },
                  textAlign: {
                    type: 'object',
                    properties: {
                      auto: { type: 'boolean' },
                      align: { type: 'string', enum: ['left', 'center', 'right'] }
                    }
                  },
                  columnWidth: {
                    type: 'object',
                    properties: {
                      type: { type: 'string', enum: ['auto', 'fitToContent', 'pixels', 'percentage'] },
                      pixels: { type: 'string' },
                      percentage: { type: 'string' }
                    }
                  }
                }
              }
            },
            required: ['expression']
          }
        }
      },
      required: ['appId', 'objectId']
    }
  },

  qlik_visualization_delete: {
    name: 'qlik_visualization_delete',
    description: 'Delete a visualization from a sheet in a Qlik Cloud app. The object will be removed from the sheet. Cloud only.',
    inputSchema: {
      type: 'object',
      properties: {
        appId: {
          type: 'string',
          description: 'ID of the Qlik app'
        },
        sheetId: {
          type: 'string',
          description: 'ID of the sheet containing the visualization'
        },
        objectId: {
          type: 'string',
          description: 'ID of the visualization to delete'
        }
      },
      required: ['appId', 'sheetId', 'objectId']
    }
  }
};
